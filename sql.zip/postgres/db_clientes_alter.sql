
-- Ejemplos de modificaciones posibles de las tablas

-- A�adir un buleano de confirmaci�n de clientes
ALTER TABLE clientes ADD COLUMN activo BOOL DEFAULT tcalle ;


-- Modificar las columnas fecha de prestaci�n por un daterange

-- Crear una regla que prohiba la eliminaci�n de un cliente
CREATE RULE elim_clientes AS
   ON DELETE TO clientes
   DO INSTEAD UPDATE clientes SET activo = false WHERE cl_nombre = OLD.cl_nombre ;
