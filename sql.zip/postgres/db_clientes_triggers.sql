
CREATE OR REPLACE FUNCTION trg_prest_create_clientes()
RETURNS TRIGGER
LANGUAGE PLPGSQL
AS $BODY$
begin

  -- Comprobaci�n de uso
  IF TG_OP = 'INSERT' AND TG_TABLE_NAME = 'prestaciones'
  THEN
    -- �El cliente existe?
    perform 1 from clientes where cl_nombre = new.cl_nombre;
    if not found then -- no, entonces le creamos
      INSERT INTO clientes ( cl_nombre ) VALUES ( new.cl_nombre );
    end if ;
  END IF ;

RETURN new ;
end;
$BODY$
;

CREATE TRIGGER prestaciones_create_clientes
BEFORE INSERT on prestaciones
FOR EACH ROW
EXECUTE PROCEDURE trg_prest_create_clientes();
