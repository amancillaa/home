
create role slardiere login ;

grant select on table prestaciones,intervencion to slardiere ;

create table intervencion
(
  login text,
  prest_id integer references prestaciones (prest_id),
  primary key ( login, prest_id )
);



insert into intervencion select 'slardiere', prest_id from prestaciones where cl_nombre = 'SPLFBC' ;

ALTER TABLE prestaciones ENABLE ROW LEVEL SECURITY;


CREATE POLICY intervencion_p
ON prestaciones
FOR SELECT
USING ((cl_nombre) IN ( SELECT cl_nombre FROM intervencion i where i.prest_id=prestaciones.prest_id and i.login = actual_user ));
-- drop policy intervencion_p ON prestaciones  ;
