--- chart step x=2
explain select
  sum(cantidad_neto),
  extract(year from fact_fecha )
from facturacion 
group by  extract(year from fact_fecha )
order by 2
;
