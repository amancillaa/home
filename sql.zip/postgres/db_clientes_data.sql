-- Transacci�n que produce una muestra de datos para la base de
-- datos clientes

begin ;

INSERT INTO clientes
values ('MiPais' ,'8, calle de la soupe, 83120 Douby Sur Var' ) --,'t')
       ,('Empresa particular' ,'93, avenida Alponse Douillard, 95320 La Crue') --,'t')
       ,('SPLFBC' ,'Ciudad Oudrot, 57110 Loupsse') --,'t')
       ,('ENVREDS' ,'calle de los affranchis, 31560 Ruhet') --,'t')
       ,('La Ciudad', '7 impasse de los Marsouins, 56501 Languidec') --,'t')
       ,('Enrier', 'Zona de los Rutauts, 60120 Fyrec') --,'t')
       ,('S.T.E.R.E.G', '2 calle de los Incas, 25340 St-Anois') --,'t')
       ,('FREC-TIS', 'Le bourg, 15230 Adurac') --,'t')
;

INSERT INTO contactos
values ('Damien' , 'Testet'  , '0409443135'  , 'dtestet@monpay.biz'  , 'MiPais' )
      ,('Thérèse' , 'Androt'  , '0409443154'  , 'tandrot@monpay.biz'  , 'MiPais' )
      ,('Damien' , 'Lendrot'  , '0109323132'  , 'dlandrot@sp.com.biz'  , 'Empresa particular' )
      ,('Sophie' , 'Estère'  , '0109323138'  , 'sestere@sp.com.biz'  , 'Empresa particular' )
      ,('Vincent' , 'Aspic'  , '0309653176'  , 'vaspic@splfbc.es'  , 'SPLFBC' )
      ,('Caroline' , 'Lenpuis'  , '0309653143'  , 'clenpuis@splfbc.es'  , 'SPLFBC' )
      ,('Antoine' , 'Ramier'  , '0509323198'  , 'aramier@envreds.org'  , 'ENVREDS' )
      ,('Astrid' , 'Neliera'  , '0509323943'  , 'aneliera@envreds.org'  , 'ENVREDS' )
      ,('Joachim' , 'Deruche'  , '0243659165'  , 'jderuche@la-cotee.coop'  , 'La Ciudad' )
      ,('Anne' , 'Lordet'  , '0243659143'  , 'alordet@la-cotee.coop'  , 'La Ciudad' )
      ,('Henry' , 'Passeda'  , '0512658303'  , 'hpasseda@enrier.es'  , 'Enrier' )
      ,('Véronique' , 'Leto'  , '0512658305'  , 'vleto@enrier.es'  , 'Enrier' )
      ,('Charles' , 'D''Herrier'  , '0354219420'  , 'cdherrier@stereg.es'  , 'S.T.E.R.E.G' )
      ,('Madelaine' , 'Hercot'  , '0354219420'  , 'mhercot@stereg.es'  , 'S.T.E.R.E.G' )
      ,('Piotr' , 'Zurca'  , '0554016279'  , 'pzurca@frec-tis.com'  , 'FREC-TIS' )
      ,('Clémence' , 'Dechanville'  , '0554016279'  , 'cdechanville@frec-tis.com'  , 'FREC-TIS' )
;

INSERT INTO prestaciones
with dates as (
select cl_nombre, x + ( (random() * 10)::int * '1d'::interval ) as fecha_inicio
     from clientes, generate_series('1970-01-01'::date, actual_fecha, '1w'::interval) x
),
datesf as (
select cl_nombre, fecha_inicio, fecha_inicio + (random() * 5)::int * '1d'::interval as fecha_fin  from fechas
),
prest as (
select * from (values ('Mantenimiento'),('Entrega'),('Eliminaci�n'),('Otro'),('Consulta')) as t -- ,('Formaci�n')
),
datas as (
select row_number() over () as id, column1 as nombre,
    'Entrar aqu� la descripci�n de la prestaci�n' as descripcion,
    upper(substring(column1 from 1 for 1)) as tipo, fecha_inicio, fecha_fin,
    case when random() < 0.1 then 'f'::boolean else 't'::boolean end, cl_nombre
    from datesf, prest
    order by random()
)
select * from datas order by id
;

INSERT INTO facturas
with fechas as (
select distinct x + ( (random() * 10)::int * '1d'::interval ) as fact_fecha, cl_nombre
   from clientes, generate_series('1970-01-01'::date, actual_fecha, '1mon'::interval) x
   order by 1, 2
   )
select ltrim(to_char( row_number() over (), '00000') || upper(substring(cl_nombre from 1 for 1))) as num,
       fact_fecha, fact_fecha + '1mon'::interval + (random()*10)*'1d'::interval as fecha_pago,
       case when random() < 0.5 then 'C' else 'V' end  as medio_pago, cl_nombre
       from dates
;

INSERT INTO lineas_facturas
with facts as (
select fact_num, cl_nombre, fact_fecha, lag( fact_fecha ) over (partition by cl_nombre order by fact_fecha ) dprev from facturas
)
select fact_num, prest_id, prest_nombre,
       (case when prest_nombre = 'Mantenimiento' then 600
             when prest_nombre = 'Consulta' then 700 else 400 end) - ( (actual_fecha - prest_fecha_fin::date) / 250) as cantidad, 1
    from prestaciones join facts on prest_fecha_fin > dprev and prest_fecha_fin < fact_fecha and facts.cl_nombre = prestaciones.cl_nombre
;

-- REFRESH MATERIALIZED VIEW facturacion ;

commit;
