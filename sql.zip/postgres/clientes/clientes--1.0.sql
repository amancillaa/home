
CREATE OR REPLACE FUNCTION cantidad_total
    ( cantidad_neto numeric, iva numeric default 20.6 )
RETURNS numeric
LANGUAGE 'plpgsql'
STABLE
AS $$
BEGIN
    RETURN cantidad_neto * (1 + (iva / 100  )) ;
END ;
$$ ;

CREATE OR REPLACE FUNCTION cantidad_factura
    (id_factura text)
RETURNS numeric
LANGUAGE 'plpgsql'
AS $$
DECLARE
  suma_total numeric ;
BEGIN
  RAISE NOTICE 'ID Factura: % ' , id_factura ;
  SELECT cantidad_total(sum (lf_cantidad)) into suma_total
    FROM lineas_facturas
    WHERE fact_num = id_factura ;
 RAISE NOTICE 'Suma : % ' , suma_total ;
RETURN suma_total ;
END ;
$$ ;
