begin;
create table formaciones  (
	f_num_becarios int,
	f_id_plandeestudios text,
	f_tipo_fomracion varchar(5) check ( f_tipo_fomracion in ('intra','inter') )
) inherits ( prestaciones ) ;

-- DROP FK lineas_facturas_prestaciones

ALTER TABLE lineas_facturas DROP CONSTRAINT lineas_facturas_prest_id_fkey ;

INSERT INTO formaciones
with dates as (
select cl_nombre, x + ( (random() * 10)::int * '1d'::interval ) as fecha_inicio
     from clientes, generate_series('1970-01-01'::date, actual_fecha, '2mon'::interval) x
),
datesf as (
select cl_nombre, fecha_inicio, fecha_inicio + (random() * 5)::int * '1d'::interval as fecha_fin  from dates
),
prest as (
select * from (values ('Formaci�n')) as t
),
datas as (
select (select max(prest_id) id from prestaciones) +  row_number() over () as id, column1 as nombre,
    'Entrar aqu� la descripci�n de la formaci�n' as descripcion,
    upper(substring(column1 from 1 for 1)) as type, fecha_inicio, fecha_fin,
    case when random() < 0.1 then 'f'::boolean else 't'::boolean end, cl_nombre,
    (random() + 80 )::int as num_becarios,
    case when random() < 0.5 then 1 else 2 end,
    case when random() < 0.9 then 'intra'::text else 'inter'::text end
    from datesf, prest
    order by random()
)
select * from datas order by id
;

INSERT INTO facturas
select ltrim(to_char( row_number() over (), '00000') ||'_F_'|| upper(substring(cl_nombre from 1 for 1))) as num,
       fact_fecha, fact_fecha + '1mon'::interval + (random()*10)*'1d'::interval as fecha_pago,
       case when random() < 0.5 then 'C' else 'V' end  as medio_pago, cl_nombre
       from (
           select distinct x + ( (random() * 10)::int * '1d'::interval ) as fact_fecha, cl_nombre
              from clientes, generate_series('1970-01-01'::date, actual_fecha, '6mon'::interval) x
           ) as y
;

INSERT INTO lineas_facturas
select fact_num, prest_id, prest_nombre, 500 as cantidad, 1
    from formaciones join
    (select fact_num, cl_nombre,
      fact_fecha, lag( fact_fecha ) over (partition by cl_nombre order by fact_fecha ) dprev
      from facturas where fact_num ~ '_F_') as facts
    on prest_fecha_fin > dprev and prest_fecha_fin < fact_fecha
    and facts.cl_nombre = formaciones.cl_nombre
    where prest_nombre = 'Formaci�n'
;


REFRESH MATERIALIZED VIEW facturacion ;

--rollback;
commit;
