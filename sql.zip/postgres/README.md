# Base de datos de clientes

Scripts que generan una base de datos de clientes

El objetivo de los scripts es ilustrar mi libro PostgreSQL Administration
(Ediciones ENI)

## Uso

Los scripts se proporcionan para funcionar con PostgreSQL 10

Para ejecutar los comandos, lo m�s sencillo es utilizar `psql` :


    psql -U postgres -f db_clientes.sql

## Almac�n

Estos scripts est�n disponibles y actualizados en el almac�n gestionado por el
autor : https://github.com/slardiere/dbclientes
