SET plprofiler.enabled TO true;
SET plprofiler.collect_interval TO 10;
select fact_num, cl_nombre, cantidad_factura( fact_num )  from facturas order by random() limit 1;
