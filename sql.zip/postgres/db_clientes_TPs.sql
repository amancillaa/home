
-- Ejemplos de modificaciones posibles de las tablas

-- A�adir un buleano de confirmaci�n de clientes
ALTER TABLE clientes ADD COLUMN activo BOOL DEFAULT tcalle ;


-- Modificar las columnas fecha de prestacion por un daterange
alter table prestaciones add column prest_fechas daterange ;
update prestaciones set prest_fechas = daterange( prest_fecha_inicio::date, prest_fecha_fin::date) ;
alter table prestaciones drop column prest_fecha_inicio, drop column prest_fecha_fin ;
create index on prestaciones using gist ( prest_fechas ) ;

-- DROP INDEX prest_fecha_idx;
-- DROP INDEX prest_fecha_deb_idx;

-- Crear una regla que prohiba la eliminaci�n de un cliente
CREATE RULE elim_clientes AS
   ON DELETE TO clientes
   DO INSTEAD UPDATE clientes SET activo = false WHERE cl_nombre = OLD.cl_nombre ;
