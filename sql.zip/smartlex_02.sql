-- HAY QUE ACCEDER A LA BASE DE DATOS 	
CREATE SCHEMA catalogo AUTHORIZATION smartlex_admin;
CREATE SCHEMA cms AUTHORIZATION smartlex_admin;


GRANT ALL ON SCHEMA catalogo TO smartlex_admin;
GRANT ALL ON SCHEMA catalogo TO smartlex_consulta;
GRANT ALL ON SCHEMA catalogo TO smartlex_grabado;
GRANT ALL ON SCHEMA catalogo TO public;

GRANT ALL ON SCHEMA cms TO smartlex_admin;
GRANT ALL ON SCHEMA cms TO smartlex_consulta;
GRANT ALL ON SCHEMA cms TO smartlex_grabado;
GRANT ALL ON SCHEMA cms TO public;


ALTER ROLE smartlex_admin SET search_path = cms,catalogo, public;
ALTER ROLE smartlex_consulta SET search_path = cms,catalogo, public;
ALTER ROLE smartlex_grabado SET search_path = cms,catalogo, public;


--ACCESS TABLES
REVOKE ALL ON ALL TABLES IN SCHEMA catalogo FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA cms FROM PUBLIC;

GRANT SELECT ON ALL TABLES IN SCHEMA catalogo TO smartlex_consulta;
GRANT SELECT ON ALL TABLES IN SCHEMA cms TO smartlex_consulta;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA catalogo TO smartlex_grabado;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA cms TO smartlex_grabado;

GRANT ALL ON ALL TABLES IN SCHEMA catalogo TO smartlex_admin;
GRANT ALL ON ALL TABLES IN SCHEMA cms TO smartlex_admin;

--ACCESS SEQUENCES
REVOKE ALL ON ALL SEQUENCES IN SCHEMA catalogo FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA cms FROM PUBLIC;

GRANT SELECT ON ALL SEQUENCES IN SCHEMA catalogo TO smartlex_consulta; -- allows the use of CURRVAL
GRANT SELECT ON ALL SEQUENCES IN SCHEMA cms TO smartlex_consulta; -- allows the use of CURRVAL

GRANT UPDATE ON ALL SEQUENCES IN SCHEMA catalogo TO smartlex_grabado; -- allows the use of NEXTVAL and SETVAL
GRANT UPDATE ON ALL SEQUENCES IN SCHEMA cms TO smartlex_grabado; -- allows the use of NEXTVAL and SETVAL

GRANT USAGE ON ALL SEQUENCES IN SCHEMA catalogo TO smartlex_grabado; -- allows the use of CURRVAL and NEXTVAL
GRANT USAGE ON ALL SEQUENCES IN SCHEMA cms TO smartlex_grabado; -- allows the use of CURRVAL and NEXTVAL

GRANT ALL ON ALL SEQUENCES IN SCHEMA catalogo TO smartlex_admin;
GRANT ALL ON ALL SEQUENCES IN SCHEMA cms TO smartlex_admin;


