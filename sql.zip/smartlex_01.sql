-- INICIALIZAMOS

drop database if exists SMARTLEX_BD;
DROP USER if exists smartlex_admin;
DROP USER if exists smartlex_consulta;
DROP USER if exists smartlex_grabado;

drop schema if exists catalogo;
drop schema if exists cms;

--- creamos los usuarios administrador, usuario de solo lectura y usuario de lectura y escritura
CREATE ROLE smartlex_admin WITH PASSWORD 'admin' LOGIN;
CREATE ROLE smartlex_consulta WITH PASSWORD 'consulta' LOGIN;
CREATE ROLE smartlex_grabado WITH PASSWORD 'grabado' LOGIN;

--- creamos la base de datos
CREATE DATABASE SMARTLEX_BD2
    WITH 
    OWNER = smartlex_admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.utf8'
    LC_CTYPE = 'en_US.utf8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;


-- QUITA CONEXION A TODOS LOS USUARIOS SMARTLEX_BD
REVOKE CONNECT ON DATABASE SMARTLEX_BD FROM PUBLIC;

--- DA ACCESO A LOS ROLES CREADOS
GRANT CONNECT ON DATABASE SMARTLEX_BD2 TO smartlex_admin;
GRANT CONNECT ON DATABASE SMARTLEX_BD2 TO smartlex_consulta;
GRANT CONNECT ON DATABASE SMARTLEX_BD2 TO smartlex_grabado;

--ACCESS SCHEMA
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO smartlex_admin;
GRANT USAGE ON SCHEMA public TO smartlex_consulta;
GRANT USAGE ON SCHEMA public TO smartlex_grabado;

