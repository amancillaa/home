docker run -it --rm --link northwind_container:postgres postgres psql -h postgres -U postgres
