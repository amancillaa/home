docker stop northwind_container
docker rm northwind_container
docker image rm northwind_image
