package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.deuda;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import butterknife.BindView;


import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DeudaTributaria;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.DeudaViewModel;
import timber.log.Timber;


public class DeudaTributariaFragment extends BaseFragment implements Injectable {

    public static final String TAG = DeudaTributariaFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.linear_layout_lc)
    LinearLayout lcList;

    @BindView(R.id.text_view_monto_pago)
    TextView textViewMontoPago;
    @BindView(R.id.text_view_fecha_pago)
    TextView textViewFechaPago;
    @BindView(R.id.text_view_fecha_cancelacion)
    TextView textViewFechaCancelacion;
    @BindView(R.id.text_view_tipo_cancelacion)
    TextView textViewTipoCancelacion;


    private View view;
    private OnFragmentIterationListener listener;
    private DeudaViewModel viewModel;

    public DeudaTributariaFragment() {
    }

    public static DeudaTributariaFragment newInstance(Bundle params) {
        DeudaTributariaFragment dtf = new DeudaTributariaFragment();
        dtf.setArguments(params);
        return dtf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_deuda_tributaria, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {
        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));

        lcList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.setLCListFragment(getArguments());
                }
            }
        });


        viewModel = ViewModelProviders.of(this,viewModelFactory).get(DeudaViewModel.class);
        ((BaseActivity)getActivity()).showLoading();

        String token = params.getString(Constantes.ARG_TOKEN);
        String idDam = params.getString(Constantes.ARG_IDDAM);

        viewModel.getDeudaTributaria(token, idDam).observe(this, response -> {

            ((BaseActivity)getActivity()).hideMessage();
            DeudaTributaria deuda = response.getDeudaTributaria();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();
            if (deuda != null) {
                cargarPantalla(deuda);
            }else if(error!=null){
                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                } else if(Constantes.ERROR_NO_FOUND.equals(error.getCod())) {
                    Timber.i(errorMsg);
                    ((BaseActivity)getActivity()).showNoFound();
                }else{
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if(throwable!=null){
                Timber.e(TAG,throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }
        });
    }

    private void cargarPantalla(DeudaTributaria deuda) {

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        symbols.setDecimalSeparator('.');
        DecimalFormat decimalFormat = new DecimalFormat("US$ #,###.00", symbols);

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        textViewMontoPago.setText(decimalFormat.format(new BigDecimal(deuda.getMontoDeuda())));
        //textViewFechaPago.setText(deuda.getFechaVencimiento());
        //textViewFechaCancelacion.setText(deuda.getFechaCancelacion());
        if(deuda.getFechaCancelacion()!=null){
            //SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            try{
                Date dateCance = formatter.parse(deuda.getFechaCancelacion());
                textViewFechaCancelacion.setText(formatter.format(dateCance));
                Date datePago = formatter.parse(deuda.getFechaVencimiento());
                textViewFechaPago.setText(formatter.format(datePago));
            }catch (Exception e){
                Log.e(TAG, "Error al cambiar formato fecha cancelacion o vencimiento del monto"+deuda.getTipoCancelacion());
            }
        }
        textViewTipoCancelacion.setText(deuda.getTipoCancelacion());
    }

    public interface OnFragmentIterationListener {
        void setLCListFragment(Bundle bundle);
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Timber.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
