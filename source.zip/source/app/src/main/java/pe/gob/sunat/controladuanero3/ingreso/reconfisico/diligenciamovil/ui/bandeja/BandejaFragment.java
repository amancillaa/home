package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja;




import android.app.SearchManager;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;



import android.widget.LinearLayout;



import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.adapter.AdapterDocumentosList;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.BandejaViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.LineItemDecoration;
import timber.log.Timber;


public class BandejaFragment extends Fragment implements Injectable {

    public static final String TAG = BandejaFragment.class.getSimpleName();


    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.recycler_bandeja)
    RecyclerView recyclerView;

    Unbinder unbinder;
    private View view;
    private AdapterDocumentosList mAdapter;
    private SearchView searchView;
    private OnFragmentIterationListener listener;
    private BandejaViewModel viewModel;

    public BandejaFragment() {
    }

   @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    public interface OnFragmentIterationListener {
        void setDeclaracionFragment(Bundle bundle);
    }

    public static BandejaFragment newInstance(Bundle params) {
        BandejaFragment bf = new BandejaFragment();
        bf.setArguments(params);

        return bf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_bandeja, container, false);
        unbinder = ButterKnife.bind(this, view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.addItemDecoration(new LineItemDecoration(this.getContext(), LinearLayout.VERTICAL));
        recyclerView.setHasFixedSize(true);

        mAdapter = new AdapterDocumentosList(this.getContext(), new DocumentosAsignados(),ItemAnimation.FADE_IN);
        recyclerView.setAdapter(mAdapter);

        mAdapter.setOnItemClickListener((view, documento, position) -> {

            if (listener != null) {

                ((BaseActivity)getActivity()).showLoading();
                Bundle bundle = getArguments();
                String token = bundle.getString(Constantes.ARG_TOKEN);

                viewModel.getListaAdvertencias(token,documento.getIdDam(),Constantes.ARG_TIPO_ADVERTENCIA_BANDEJA).observe(getActivity(), response -> {

                    ((BaseActivity)getActivity()).hideMessage();
                    List<Advertencia> advertencias = response.getAdvertencias();
                    ErrorGeneral error  = response.getErrorGeneral();
                    Throwable throwable = response.getError();
                    if(advertencias!=null){
                        if(advertencias.size()==0){
                            bundle.putString(Constantes.ARG_IDDAM,documento.getIdDam());
                            bundle.putString(Constantes.FEC_RECEP,documento.getFecNumeracion());
                            listener.setDeclaracionFragment(bundle);
                        }else{
                            List<String> lstValidaciones = advertencias.stream().map(Advertencia::getDetalle).collect(Collectors.toList());
                            ((BaseActivity)getActivity()).showWarningDialog(lstValidaciones,documento.getIdDam(),Constantes.ARG_TIPO_ADVERTENCIA_BANDEJA);
                        }
                    }else if(error!=null){
                        String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                        if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                            Timber.w(errorMsg);
                            ((BaseActivity)getActivity()).showTokenDialog();
                        }else {
                            Timber.e(errorMsg);
                            ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                        }
                    }else if(throwable!=null){
                        Timber.e(throwable.getMessage());
                        ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
                    }

                });
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        viewModel = ViewModelProviders.of(this,viewModelFactory).get(BandejaViewModel.class);


        String token = getArguments().getString(Constantes.ARG_TOKEN);
        String codFuncionario = getArguments().getString(Constantes.ARG_COD_FUNCIONARIO);

        viewModel.getListaDocumentosAsignados(token,codFuncionario).observe(this,response -> {

            ((BaseActivity)getActivity()).hideMessage();

            DocumentosAsignados documentosAsignados = response.getDocumentosAsignados();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if(documentosAsignados!=null){
                mAdapter.addItems(documentosAsignados);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                }else if (Constantes.ERROR_NO_FOUND.equals(error.getCod())){
                    Timber.i(errorMsg);
                    ((BaseActivity)getActivity()).showNoFound();
                }else {
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_bandeja, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_buscar).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //mAdapter.getFilter().filter(query.concat(menu.findItem(R.id.menu_filtrar).toString()));
                if(!"".equals(searchView.getQueryHint()) &&  !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if(!"".equals(searchView.getQueryHint()) && !searchView.getQueryHint().toString().contains("Buscar")){//bypass al hint
                    query=searchView.getQueryHint()+query;
                }
                mAdapter.getFilter().filter(query);
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {

            /**FILTROS**/
            case R.id.submenu_f_G160:
                mAdapter.getFilter().filter("G160:"+this.searchView.getQuery());
                break;
            case R.id.submenu_f_OEA:
                mAdapter.getFilter().filter("OEA:"+this.searchView.getQuery());
                break;
            /**ORDENAMIENTOS**/
            case R.id.submenu_o_fechaasig:
                mAdapter.sorted("FECHA_ASIG");
                break;
            case R.id.submenu_o_nro_dam:
                mAdapter.sorted("IDDAM");
                break;
            case R.id.submenu_o_cant_series:
                mAdapter.sorted("CANTSERIES");
                break;
        }

        return true;
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
