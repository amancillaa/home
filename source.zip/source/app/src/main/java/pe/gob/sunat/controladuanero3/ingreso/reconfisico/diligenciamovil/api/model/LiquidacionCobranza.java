package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import java.util.Date;


/**
 * LiquidacionCobranza
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "nroLC",
        "fechaLiquidacion",
        "monto",
        "fechaCancelacion",
        "sustento"
})
public class LiquidacionCobranza extends BaseModel{

    @JsonProperty("nroLC")
    private String nroLC;

    @JsonProperty("fechaLiquidacion")
    private String fechaLiquidacion;

    @JsonProperty("monto")
    private String monto;

    @JsonProperty("fechaCancelacion")
    private String fechaCancelacion;

    @JsonProperty("sustento")
    private String sustento;

    @JsonProperty("cancelacion")
    private String cancelacion;

    @JsonProperty("tipoLC")
    private String tipoLC;

   /** SET AND GET **/

    public String getNroLC() {
        return nroLC;
    }

    public void setNroLC(String nroLC) {
        this.nroLC = nroLC;
    }

    public String getFechaLiquidacion() {
        return fechaLiquidacion;
    }

    public void setFechaLiquidacion(String fechaLiquidacion) {
        this.fechaLiquidacion = fechaLiquidacion;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getFechaCancelacion() {
        return fechaCancelacion;
    }

    public void setFechaCancelacion(String fechaCancelacion) {
        this.fechaCancelacion = fechaCancelacion;
    }

    public String getSustento() {
        return sustento;
    }

    public void setSustento(String sustento) {
        this.sustento = sustento;
    }

    public String getCancelacion() {
        return cancelacion;
    }

    public void setCancelacion(String cancelacion) {
        this.cancelacion = cancelacion;
    }

    public String getTipoLC() {
        return tipoLC;
    }

    public void setTipoLC(String tipoLC) {
        this.tipoLC = tipoLC;
    }
}



