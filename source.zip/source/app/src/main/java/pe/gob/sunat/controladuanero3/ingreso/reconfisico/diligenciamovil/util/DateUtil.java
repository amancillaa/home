package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    /**
     * Convierte un <b>Date</b> a String usando el formato <b>format</b>
     * si ocurre una excepcion devuelve null
     * @param date
     * @param format
     * @return
     */
    public static String dateTimeToStringConFormatoISO(Date date){
        String format="yyyy-MM-dd'T'HH:mm:ss";
        return dateToStringSilent(date, format);
    }




    /**
     * Convierte un <b>Date</b> a String usando el formato <b>format</b>
     * si ocurre una excepcion devuelve null
     * @param date
     * @param format
     * @return
     */
    public static String dateToStringSilent(Date date, String format){
        String dateAsString = null;
        try{
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            dateAsString = sdf.format(date);
        }catch (Exception e) {}
        return dateAsString;
    }


    public static Date dateToStringConFormatoISO(String dateFormatISO){

        String format="yyyy-MM-dd'T'HH:mm:ss";
        DateFormat df = new SimpleDateFormat(format);
        Date fecha = null;
        try{
            fecha = df.parse(dateFormatISO);
        }catch (Exception e){ }
        return fecha;
    }

}
