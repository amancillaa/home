package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;

public class DiligenciaPreliminarFragment extends BaseFragment {


    public static final String TAG = DiligenciaPreliminarFragment.class.getSimpleName();

    public static DiligenciaPreliminarFragment newInstance(Bundle params) {

        DiligenciaPreliminarFragment bf = new DiligenciaPreliminarFragment();
        bf.setArguments(params);
        return bf;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_diligencia_preliminar, container, false);
    }

}
