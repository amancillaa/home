package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * Precinto
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numPrecinto"
})
public class Precinto {


    @JsonProperty("numPrecinto")
    private String numPrecinto;

    public String getNumPrecinto() {
        return numPrecinto;
    }

    public void setNumPrecinto(String numPrecinto) {
        this.numPrecinto = numPrecinto;
    }
}



