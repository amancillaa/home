
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "size",
    "totalElements",
    "totalPages",
    "number"
})
public class Page {

    @JsonProperty("size")
    public Integer size;
    @JsonProperty("totalElements")
    public Integer totalElements;
    @JsonProperty("totalPages")
    public Integer totalPages;
    @JsonProperty("number")
    public Integer number;

}
