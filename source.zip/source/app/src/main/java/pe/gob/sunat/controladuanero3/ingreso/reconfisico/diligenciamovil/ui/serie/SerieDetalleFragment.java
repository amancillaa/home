package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Convenio;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.SerieViewModel;
import timber.log.Timber;

public class SerieDetalleFragment extends BaseFragment implements Injectable {

    public static final String TAG = SerieDetalleFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.linear_layout_items)
    LinearLayout linearLayoutItems;
    @BindView(R.id.text_view_partida)
    TextView textViewPartida;
    @BindView(R.id.text_view_descripcion)
    TextView textViewDescripcion;
    @BindView(R.id.text_view_estado)
    TextView textViewEstado;
    @BindView(R.id.text_view_fob)
    TextView textViewFob;
    @BindView(R.id.text_view_convenios)
    TextView textViewConvenios;
    @BindView(R.id.text_view_cantidad_unid_fisica)
    TextView textViewCantidadUnidFisica;
    @BindView(R.id.text_view_pais_origen)
    TextView textViewPaisOrigen;


    private View view;
    private OnFragmentIterationListener listener;
    private SerieViewModel viewModel;

    public interface OnFragmentIterationListener {
        void setItemsFragment(Bundle bundle);
    }

    public SerieDetalleFragment() {
    }

    public static SerieDetalleFragment newInstance(Bundle params) {
        SerieDetalleFragment sdf = new SerieDetalleFragment();
        sdf.setArguments(params);
        return sdf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, viewModelFactory).get(SerieViewModel.class);

        Bundle params = getArguments();
        String token = params.getString(Constantes.ARG_TOKEN);
        String idDam = params.getString(Constantes.ARG_IDDAM);
        String idSerie = params.getString(Constantes.ARG_IDSERIE);


        viewModel.getSerie(token, idDam, idSerie).observe(this, response -> {

            ((BaseActivity)getActivity()).hideMessage();
            Serie serie = response.getSerie();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if (serie!=null) {
                cargarPantalla(serie);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                }else {
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }

        });

    }

    private void cargarPantalla(Serie serie) {

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        symbols.setDecimalSeparator('.');
        DecimalFormat decimalFormat = new DecimalFormat("US$ #,###.00", symbols);

        textViewPartida.setText(serie.getNumPartNandi());
        textViewDescripcion.setText(serie.getDesComer()+" - "+serie.getDesFormaPresen()+" - "+
        serie.getDesMateComp()+" - "+serie.getDesUsoAplic()+" - "+serie.getDesOtrosCarac());
        textViewEstado.setText(serie.getCodEstMerc().getCodDesc());
        textViewFob.setText(decimalFormat.format(serie.getMtoFobDol() != null ? serie.getMtoFobDol() : 0));
        String codlibe = "---";
        String tpn = "---";
        String tpi = "---";
        if (serie.getConvenios() != null) {
            for (Convenio convenio : serie.getConvenios()) {
                if ("C".equals(convenio.getTipConvenio())) {
                    codlibe = convenio.getCodConvenio();
                } else if ("T".equals(convenio.getTipConvenio())) {
                    tpn = "TPN " + convenio.getCodConvenio();
                } else if ("I".equals(convenio.getTipConvenio())) {
                    tpi = "TPI " + convenio.getCodConvenio();
                }
            }
        }
        textViewConvenios.setText(tpi + " / " + tpn + " / " + codlibe);
        textViewCantidadUnidFisica.setText(serie.getCntUniFis() + " " + serie.getCodUniFisica().getCodDesc());
        textViewPaisOrigen.setText(serie.getPaisOrigen().getCodDesc());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_serie_detalle, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {
        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));
        linearLayoutItems.setOnClickListener(v -> {
            if (listener != null) {
                listener.setItemsFragment(params);
            }
        });
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
