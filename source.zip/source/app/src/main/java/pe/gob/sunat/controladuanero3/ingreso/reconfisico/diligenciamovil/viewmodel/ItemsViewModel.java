package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.ItemsResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;
import timber.log.Timber;

public class ItemsViewModel extends AndroidViewModel {

    public static final String TAG = ItemsViewModel.class.getSimpleName();

    private DamRepository damRepository;
    private LiveData<ItemsResponse> itemsResponse;

    @Inject
    public ItemsViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository
    ) {
        super(application);
        this.damRepository = damRepository;
        itemsResponse = new MediatorLiveData<>();
    }

    public LiveData<ItemsResponse> getListaItems (String token, String idDam, String numSecSerie){

        String pk = idDam.concat("-").concat(numSecSerie);

        if(itemsResponse.getValue() == null
             || !pk.equals(itemsResponse.getValue().getPk())) {
            //itemsResponse.addSource(damRepository.getListItems(token, idDam,numSecSerie), response -> itemsResponse.setValue(response));
            itemsResponse = damRepository.getListItems(token, idDam,numSecSerie);
        }

        Timber.d("getListaItems(idDam:%s,numSecSerie:%s)->response(%s)",idDam,numSecSerie,itemsResponse.getValue());

        return itemsResponse;
    }
}
