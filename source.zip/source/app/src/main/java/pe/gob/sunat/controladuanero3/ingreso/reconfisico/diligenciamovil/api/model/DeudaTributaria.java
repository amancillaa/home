package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import java.util.Date;

/**
 * DeudaTributaria
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "montoDeuda",
        "fechaVencimiento",
        "fechaCancelacion",
        "tipoCancelacion"
})
public class DeudaTributaria {

    @JsonProperty("montoDeuda")
    private String montoDeuda;

    @JsonProperty("fechaVencimiento")
    private String fechaVencimiento;

    @JsonProperty("fechaCancelacion")
    private String fechaCancelacion;

    @JsonProperty("tipoCancelacion")
    private String tipoCancelacion;

    /******************* GET AND SET ***********************/

    public String getMontoDeuda() {
        return montoDeuda;
    }

    public void setMontoDeuda(String montoDeuda) {
        this.montoDeuda = montoDeuda;
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getFechaCancelacion() {
        return fechaCancelacion;
    }

    public void setFechaCancelacion(String fechaCancelacion) {
        this.fechaCancelacion = fechaCancelacion;
    }

    public String getTipoCancelacion() {
        return tipoCancelacion;
    }

    public void setTipoCancelacion(String tipoCancelacion) {
        this.tipoCancelacion = tipoCancelacion;
    }
}



