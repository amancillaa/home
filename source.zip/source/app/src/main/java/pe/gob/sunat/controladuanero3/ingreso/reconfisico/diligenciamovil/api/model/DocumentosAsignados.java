package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * DocumentosAsignados
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "links",
    "content",
    "page"
})
public class DocumentosAsignados {

    @JsonProperty("links")
    private List<Link> links;
    @JsonProperty("content")
    private List<DocumentoAsignado> documentos;
    @JsonProperty("page")
    private Page page;

    private List<DocumentoAsignado> documentosFiltrados = new ArrayList<>();

    /*** SET AND GET ***/
    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }

    public List<DocumentoAsignado> getDocumentos() {
        return documentos;
    }

    public void setDocumentos(List<DocumentoAsignado> documentos) {
        this.documentos = documentos;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public List<DocumentoAsignado> getDocumentosFiltrados() {
        return documentosFiltrados;
    }

    public void setDocumentosFiltrados(List<DocumentoAsignado> documentosFiltrados) {
        this.documentosFiltrados = documentosFiltrados;
    }
}
