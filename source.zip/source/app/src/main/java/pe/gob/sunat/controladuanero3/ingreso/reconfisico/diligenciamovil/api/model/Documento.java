
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.ArrayList;
import java.util.List;


/**
 * Documento
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "links"
})
public class Documento {

    @JsonProperty("links")
    private List<Link> links;


}



