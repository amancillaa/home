package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.ItemResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;
import timber.log.Timber;


public class ItemViewModel extends AndroidViewModel {

    public static final String TAG = ItemViewModel.class.getSimpleName();

    private DamRepository damRepository;
    private LiveData<ItemResponse> itemResponse;

    @Inject
    public ItemViewModel(
            @NonNull Application application,
            @NonNull DamRepository damRepository
    ) {
        super(application);
        this.damRepository = damRepository;
        itemResponse = new MediatorLiveData<>();
    }

    public LiveData<ItemResponse> getItem (String token, String idDam, String numSecSerie, String numSecItem){

        String pk = idDam.concat("-").concat(numSecSerie).concat("-").concat(numSecItem);

        if(itemResponse.getValue() == null
             || !pk.equals(itemResponse.getValue().getPk())) {

            //itemResponse.addSource(damRepository.getItem(token, idDam, numSecSerie, numSecItem), response -> itemResponse.setValue(response));
            itemResponse = damRepository.getItem(token, idDam, numSecSerie, numSecItem);
        }
        Timber.d("getItem(idDam:%s,numSecSerie:%s,numSecItem:%s)->response(%s)",idDam,numSecSerie,numSecItem,itemResponse.getValue());

        return itemResponse;
    }
}
