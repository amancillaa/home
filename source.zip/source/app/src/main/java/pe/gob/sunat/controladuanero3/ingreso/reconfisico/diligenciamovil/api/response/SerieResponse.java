package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;


public class SerieResponse extends BaseResponse{

    private Serie serie;
    private String pk;

    /*** CONSTRUCTORES ***/
    public SerieResponse(Serie serie,String pk){
        this.error = null;
        this.errorGeneral = null;
        this.serie = serie;
        this.pk= pk;
    }

    public SerieResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.serie = null;
    }

    public SerieResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.serie = null;
    }



    /******** SET AND GET*********/

    public String getPk() {
        return pk;
    }

    public void setPk(String pk) {
        this.pk = pk;
    }

    public Serie getSerie() {
        return serie;
    }

    public void setSerie(Serie serie) {
        this.serie = serie;
    }
}
