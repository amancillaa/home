package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import retrofit2.Call;

import retrofit2.http.*;





public interface DiligenciaApi {
  
  /**
   * Retorna el tipo de diligencia solicitado
   *
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @param tipo tipo de diligencia por ejemplo diligencia preliminar (required)
   * @return Call&lt;Diligencia&gt;
   */
  @GET("/v1/controladuanero/declaraciones/{idDam}/diligencias/{tipo}")
  Call<Diligencia> buscarDiligenciaPorTipo(
          @Header("Authorization") String authHeader,
          @Path("idDam") String idDam,
          @Path("tipo") String tipo
  );

  
  /**
   * Registra diligencia
   *
   * @param body DIligencia que se va a grabar (required)
   * @param idDam idDam&#x3D;codAduana-annPresen-codRegimen-numDeclaracion o idDam&#x3D;numCorreDoc (required)
   * @return Call&lt;Void&gt;
   */
  @Headers({
    "DocumentoAsignado-Type:application/json"
  })
  @POST("/v1/controladuanero/declaraciones/{idDam}/diligencias")
  Call<Void> registrarDiligencia(
          @Header("Authorization") String authHeader,
          @Body Diligencia body,
          @Path("idDam") String idDam
  );

  
}

