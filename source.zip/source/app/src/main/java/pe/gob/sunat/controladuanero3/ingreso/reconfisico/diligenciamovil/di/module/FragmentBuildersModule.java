package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.module;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.BandejaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.ContenedoresListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DeclaracionFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.DocTransporteListFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.diligencia.DiligenciaFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item.ItemFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieDetalleFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.SerieFragment;

@Module
public abstract class FragmentBuildersModule {

    @ContributesAndroidInjector
    abstract BandejaFragment contributeBandejaFragment();

    @ContributesAndroidInjector
    abstract DeclaracionFragment contributeDeclaracionFragment();

    @ContributesAndroidInjector
    abstract ContenedoresListFragment contributeContenedoresListFragment();

    @ContributesAndroidInjector
    abstract DocTransporteListFragment contributeDocTransporteListFragment();

    @ContributesAndroidInjector
    abstract SerieFragment contributeSerieFragment();

    @ContributesAndroidInjector
    abstract SerieDetalleFragment contributeSerieDetalleFragment();

    @ContributesAndroidInjector
    abstract ItemFragment contributeItemFragment();

    @ContributesAndroidInjector
    abstract ItemDetalleFragment contributeItemDetalleFragment();

    @ContributesAndroidInjector
    abstract DiligenciaFragment contributeDiligenciaFragment();

}
