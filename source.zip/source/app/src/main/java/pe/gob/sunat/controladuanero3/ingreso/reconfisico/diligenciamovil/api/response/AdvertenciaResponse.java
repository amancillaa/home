package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Advertencia;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class AdvertenciaResponse extends BaseResponse {

    private List<Advertencia> advertencias;
    private String pk;


    public AdvertenciaResponse(List<Advertencia> advertencias,String pk) {
        this.error = null;
        this.errorGeneral = null;
        this.advertencias = advertencias;
        this.pk= pk;
    }

    public AdvertenciaResponse(ErrorGeneral errorGeneral) {
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.advertencias = null;
    }

    public AdvertenciaResponse(Throwable error) {
        this.error = error;
        this.errorGeneral = null;
        this.advertencias = null;
    }

    /***** SET AND GET ***/
    public List<Advertencia> getAdvertencias() {
        return advertencias;
    }

    public void setAdvertencias(List<Advertencia> advertencias) {
        this.advertencias = advertencias;
    }


    public String getPk() {
        return pk;
    }

    public void setPk(String pk) {
        this.pk = pk;
    }
}
