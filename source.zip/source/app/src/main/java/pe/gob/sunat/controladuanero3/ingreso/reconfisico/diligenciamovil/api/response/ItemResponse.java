package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;

public class ItemResponse extends BaseResponse {

    private Item item;
    private String pk;
    /*** CONSTRUCTORES ***/
    public ItemResponse(Item item, String pk){
        this.error = null;
        this.errorGeneral = null;
        this.item = item;
        this.pk = pk;
    }

    public ItemResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.item = null;
    }

    public ItemResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.item = null;
    }

    public String getPk() {
        return pk;
    }

    public void setPk(String pk) {
        this.pk = pk;
    }

    /******** SET AND GET*********/


    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }
}
