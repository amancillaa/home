
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.math.BigDecimal;


/**
 * Contiene los datos de los items de la factura provenientes de la declaracion del valor
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numSecItem",
        "factura",
        "paisOrigen",
        "paisAdquisicion",
        "unidadComercial",
        "cntUni",
        "desComer",
        "desMarca",
        "desModelo",
        "estadoMercancia",
        "indDeduc",
        "indSoftware",
        "annFabricacion",
        "codProd",
        "desCaracteristicas",
        "desClaseVari",
        "desUsoAplic",
        "desMaterialComp",
        "mtoAjuUnitario",
        "mtoFobItem",
        "numParArancel",
        "mtoValDudaRef",
        "indOtros",
        "numItemComprob",
        "links"
})
public class Item extends BaseModel{


    @JsonProperty("numSecItem")
    private String numSecItem;

    @JsonProperty("factura")
    private Factura factura;

    @JsonProperty("paisOrigen")
    private Catalogo paisOrigen;

    @JsonProperty("paisAdquisicion")
    private Catalogo paisAdquisicion;

    @JsonProperty("unidadComercial")
    private Catalogo unidadComercial;

    @JsonProperty("cntUni")
    private BigDecimal cntUni;

    @JsonProperty("desComer")
    private String desComer;

    @JsonProperty("desMarca")
    private String desMarca;

    @JsonProperty("desModelo")
    private String desModelo;

    @JsonProperty("estadoMercancia")
    private Catalogo estadoMercancia;

    @JsonProperty("indDeduc")
    private String indDeduc;

    @JsonProperty("indSoftware")
    private String indSoftware;

    @JsonProperty("annFabricacion")
    private String annFabricacion;

    @JsonProperty("codProd")
    private String codProd;

    @JsonProperty("desCaracteristicas")
    private String desCaracteristicas;

    @JsonProperty("desClaseVari")
    private String desClaseVari;

    @JsonProperty("desUsoAplic")
    private String desUsoAplic;

    @JsonProperty("desMaterialComp")
    private String desMaterialComp;
/*
    @JsonProperty("mtoFobUnitario")
    private BigDecimal mtoFobUnitario;
*/
    @JsonProperty("mtoAjuUnitario")
    private BigDecimal mtoAjuUnitario;

    @JsonProperty("mtoFobItem")
    private BigDecimal mtoFobItem;

    @JsonProperty("numParArancel")
    private String numParArancel;

    @JsonProperty("mtoValDudaRef")
    private BigDecimal mtoValDudaRef;

    @JsonProperty("indOtros")
    private String indOtros;

    @JsonProperty("numItemComprob")
    private String numItemComprob;

    @JsonProperty("links")
    private List<Link> links;

    /******************* GET AND SET ***********************/


    public String getNumSecItem() {
        return numSecItem;
    }

    public void setNumSecItem(String numSecItem) {
        this.numSecItem = numSecItem;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }

    public Catalogo getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(Catalogo paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public Catalogo getPaisAdquisicion() {
        return paisAdquisicion;
    }

    public void setPaisAdquisicion(Catalogo paisAdquisicion) {
        this.paisAdquisicion = paisAdquisicion;
    }

    public Catalogo getUnidadComercial() {
        return unidadComercial;
    }

    public void setUnidadComercial(Catalogo unidadComercial) {
        this.unidadComercial = unidadComercial;
    }

    public BigDecimal getCntUni() {
        return cntUni;
    }

    public void setCntUni(BigDecimal cntUni) {
        this.cntUni = cntUni;
    }

    public String getDesComer() {
        return desComer;
    }

    public void setDesComer(String desComer) {
        this.desComer = desComer;
    }

    public String getDesMarca() {
        return desMarca;
    }

    public void setDesMarca(String desMarca) {
        this.desMarca = desMarca;
    }

    public String getDesModelo() {
        return desModelo;
    }

    public void setDesModelo(String desModelo) {
        this.desModelo = desModelo;
    }

    public Catalogo getEstadoMercancia() {
        return estadoMercancia;
    }

    public void setEstadoMercancia(Catalogo estadoMercancia) {
        this.estadoMercancia = estadoMercancia;
    }

    public String getIndDeduc() {
        return indDeduc;
    }

    public void setIndDeduc(String indDeduc) {
        this.indDeduc = indDeduc;
    }

    public String getIndSoftware() {
        return indSoftware;
    }

    public void setIndSoftware(String indSoftware) {
        this.indSoftware = indSoftware;
    }

    public String getAnnFabricacion() {
        return annFabricacion;
    }

    public void setAnnFabricacion(String annFabricacion) {
        this.annFabricacion = annFabricacion;
    }

    public String getCodProd() {
        return codProd;
    }

    public void setCodProd(String codProd) {
        this.codProd = codProd;
    }

    public String getDesCaracteristicas() {
        return desCaracteristicas;
    }

    public void setDesCaracteristicas(String desCaracteristicas) {
        this.desCaracteristicas = desCaracteristicas;
    }

    public String getDesClaseVari() {
        return desClaseVari;
    }

    public void setDesClaseVari(String desClaseVari) {
        this.desClaseVari = desClaseVari;
    }

    public String getDesUsoAplic() {
        return desUsoAplic;
    }

    public void setDesUsoAplic(String desUsoAplic) {
        this.desUsoAplic = desUsoAplic;
    }

    public String getDesMaterialComp() {
        return desMaterialComp;
    }

    public void setDesMaterialComp(String desMaterialComp) {
        this.desMaterialComp = desMaterialComp;
    }

    public BigDecimal getMtoAjuUnitario() {
        return mtoAjuUnitario;
    }

    public void setMtoAjuUnitario(BigDecimal mtoAjuUnitario) {
        this.mtoAjuUnitario = mtoAjuUnitario;
    }

    public BigDecimal getMtoFobItem() {
        return mtoFobItem;
    }

    public void setMtoFobItem(BigDecimal mtoFobItem) {
        this.mtoFobItem = mtoFobItem;
    }

    public String getNumParArancel() {
        return numParArancel;
    }

    public void setNumParArancel(String numParArancel) {
        this.numParArancel = numParArancel;
    }

    public BigDecimal getMtoValDudaRef() {
        return mtoValDudaRef;
    }

    public void setMtoValDudaRef(BigDecimal mtoValDudaRef) {
        this.mtoValDudaRef = mtoValDudaRef;
    }

    public String getIndOtros() {
        return indOtros;
    }

    public void setIndOtros(String indOtros) {
        this.indOtros = indOtros;
    }

    public String getNumItemComprob() {
        return numItemComprob;
    }

    public void setNumItemComprob(String numItemComprob) {
        this.numItemComprob = numItemComprob;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }
}



