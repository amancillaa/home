package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"numCorredoc",
    "aduanaDeclaracion",
    "numDeclaracion",
    "annPresen",
    "regimen",
    "idDam",
    "annOrden",
    "numOrden",
    "modalidad",
    "tipoDespacho",
    "tipoLugarRecepcion",
    "codLocalAnexo",
    "codTipAduDest",
    "codAduDest",
    "mtoTotFobDol",
    "mtoTotFleteDol",
    "mtoTotSegDol",
    "mtoTotAjustesDol",
    "mtoTotOtrosAjuste",
    "mtoTotValorAdu",
    "cntPesoBrutoTotal",
    "cntPesoNetoTotal",
    "cntTotBultos",
    "cntTotSeries",
    "mtoTotAutoLiq",
    "estadoDeclaracion",
    "modalidadPago",
    "entidadPago",
    "cntPlzCredito",
    "fecDocPagoBco",
    "indExportTerceros",
    "tipoTratamientoMercancia",
    "viaTransporte",
    "tipoManifiesto",
    "codPuerPreseMani",
    "fecTerm",
    "fecIniEmbarque",
    "codPuerDesp",
    "canalControl",
    "mtoTotDeudaSol",
    "mtoTotPagado",
    "fecDeclaracion",
    "fecAutLevante",
    "fecConclusion",
    "fecRegulariza",
    "fecAmpliacion",
    "codRucLugRecep",
    "cntTqUniFis",
    "cntTqUniCom",
    "codProdUrgente",
    "fecFinProvsional",
    "manifiesto",
    "numViaje",
    "mtoFobFactu",
    "numCtacte",
    "fecCarcr",
    "mtoTotDeudaDol",
    "indEscaner",
    "codMotivoCanalAsig",
    "fecVencRegula",
    "indSocorro",
    "fecRecep",
    "fecRereg",
    "fecVenRegimen",
    "codDigVeri",
    "fecLlegada",
    "fecSalTerAlm",
    "FecVenConclu",
    "codTipoEmbarque",
    "codFormaEmbarque",
    "codPaisDestino",
    "codPuertoEmbar",
    "codUltViaTrasla",
    "mtoClausulaVenta",
    "mtoComisionVenta",
    "mtoGastosDeduc",
    "codCategoria",
    "consignatario",
    "agenteAduana",
    "esOEA",
    "tieneGarantia160",
    "documentosTransporte",
    "contenedores",
    "links"
})
public class Declaracion {

    @JsonProperty("numCorredoc")
    private String numCorredoc;

    @JsonProperty("aduanaDeclaracion")
    private Catalogo aduanaDeclaracion;

    @JsonProperty("numDeclaracion")
    private String numDeclaracion;

    @JsonProperty("annPresen")
    private String annPresen;

    @JsonProperty("regimen")
    private Catalogo regimen;

    @JsonProperty("idDam")
    private String idDam;

    @JsonProperty("annOrden")
    private String annOrden;

    @JsonProperty("numOrden")
    private String numOrden;

    @JsonProperty("modalidad")
    private Catalogo modalidad;

    @JsonProperty("tipoDespacho")
    private Catalogo tipoDespacho;

    @JsonProperty("tipoLugarRecepcion")
    private Catalogo tipoLugarRecepcion;

    /*
    @JsonProperty("lugarRecepcion")
    private Catalogo lugarRecepcion;*/

    @JsonProperty("codLocalAnexo")
    private String codLocalAnexo;

    @JsonProperty("codTipAduDest")
    private String codTipAduDest;

    @JsonProperty("codAduDest")
    private String codAduDest;

    @JsonProperty("mtoTotFobDol")
    private BigDecimal mtoTotFobDol;

    @JsonProperty("mtoTotFleteDol")
    private BigDecimal mtoTotFleteDol;

    @JsonProperty("mtoTotSegDol")
    private BigDecimal mtoTotSegDol;

    @JsonProperty("mtoTotAjustesDol")
    private BigDecimal mtoTotAjustesDol;

    @JsonProperty("mtoTotOtrosAjuste")
    private BigDecimal mtoTotOtrosAjuste;

    @JsonProperty("mtoTotValorAdu")
    private BigDecimal mtoTotValorAdu;

    @JsonProperty("cntPesoBrutoTotal")
    private BigDecimal cntPesoBrutoTotal;

    @JsonProperty("cntPesoNetoTotal")
    private BigDecimal cntPesoNetoTotal;

    @JsonProperty("cntTotBultos")
    private BigDecimal cntTotBultos;

    @JsonProperty("cntTotSeries")
    private BigDecimal cntTotSeries;

    @JsonProperty("mtoTotAutoLiq")
    private BigDecimal mtoTotAutoLiq;

    @JsonProperty("estadoDeclaracion")
    private Catalogo estadoDeclaracion;

    @JsonProperty("modalidadPago")
    private Catalogo modalidadPago;

    @JsonProperty("entidadPago")
    private Catalogo entidadPago;

    @JsonProperty("cntPlzCredito")
    private String cntPlzCredito;

    @JsonProperty("fecDocPagoBco")
    private String fecDocPagoBco;

    @JsonProperty("indExportTerceros")
    private String indExportTerceros;

    @JsonProperty("tipoTratamientoMercancia")
    private Catalogo tipoTratamientoMercancia;

    @JsonProperty("viaTransporte")
    private Catalogo viaTransporte;

    @JsonProperty("tipoManifiesto")
    private Catalogo tipoManifiesto;

    @JsonProperty("codPuerPreseMani")
    private String codPuerPreseMani;

    @JsonProperty("fecTerm")
    private String fecTerm;

    @JsonProperty("fecIniEmbarque")
    private String fecIniEmbarque;

    @JsonProperty("codPuerDesp")
    private String codPuerDesp;

    @JsonProperty("canalControl")
    private Catalogo canalControl;

    @JsonProperty("mtoTotDeudaSol")
    private BigDecimal mtoTotDeudaSol;

    @JsonProperty("mtoTotPagado")
    private BigDecimal mtoTotPagado;

    @JsonProperty("fecDeclaracion")
    private Date fecDeclaracion;

    @JsonProperty("fecAutLevante")
    private Date fecAutLevante;

    @JsonProperty("fecConclusion")
    private Date fecConclusion;

    @JsonProperty("fecRegulariza")
    private Date fecRegulariza;

    @JsonProperty("fecAmpliacion")
    private Date fecAmpliacion;

    @JsonProperty("codRucLugRecep")
    private String codRucLugRecep;

    @JsonProperty("cntTqUniFis")
    private BigDecimal cntTqUniFis;

    @JsonProperty("cntTqUniCom")
    private BigDecimal cntTqUniCom;

    @JsonProperty("codProdUrgente")
    private String codProdUrgente;

    @JsonProperty("fecFinProvsional")
    private String fecFinProvsional;

    @JsonProperty("manifiesto")
    private Manifiesto manifiesto;

    @JsonProperty("numViaje")
    private String numViaje;

    @JsonProperty("mtoFobFactu")
    private BigDecimal mtoFobFactu;

    @JsonProperty("numCtacte")
    private String numCtacte;

    @JsonProperty("fecCarcr")
    private Date fecCarcr;

    @JsonProperty("mtoTotDeudaDol")
    private BigDecimal mtoTotDeudaDol;

    @JsonProperty("indEscaner")
    private String indEscaner;

    @JsonProperty("codMotivoCanalAsig")
    private String codMotivoCanalAsig;

    @JsonProperty("fecVencRegula")
    private Date fecVencRegula;

    @JsonProperty("indSocorro")
    private String indSocorro;

    @JsonProperty("fecRecep")
    private Date fecRecep;

    @JsonProperty("fecRereg")
    private Date fecRereg;

    @JsonProperty("fecVenRegimen")
    private Date fecVenRegimen;

    @JsonProperty("codDigVeri")
    private String codDigVeri;

    @JsonProperty("fecLlegada")
    private Date fecLlegada;

    @JsonProperty("fecSalTerAlm")
    private Date fecSalTerAlm;
/*
    @JsonProperty("codEstRegul")
    private String codEstRegul;
*/
    @JsonProperty("FecVenConclu")
    private Date fecVenConclu;

    @JsonProperty("codTipoEmbarque")
    private String codTipoEmbarque;

    @JsonProperty("codFormaEmbarque")
    private String codFormaEmbarque;

    @JsonProperty("codPaisDestino")
    private String codPaisDestino;

    @JsonProperty("codPuertoEmbar")
    private String codPuertoEmbar;

    @JsonProperty("codUltViaTrasla")
    private String codUltViaTrasla;

    @JsonProperty("mtoClausulaVenta")
    private BigDecimal mtoClausulaVenta;

    @JsonProperty("mtoComisionVenta")
    private BigDecimal mtoComisionVenta;

    @JsonProperty("mtoGastosDeduc")
    private BigDecimal mtoGastosDeduc;

    @JsonProperty("codCategoria")
    private String codCategoria;

    @JsonProperty("consignatario")
    private Participante consignatario;

    @JsonProperty("agenteAduana")
    private Participante agenteAduana;

    @JsonProperty("esOEA")
    private Boolean esOEA;

    @JsonProperty("tieneGarantia160")
    private Boolean tieneGarantia160;

    @JsonProperty("documentosTransporte")
    private List<DocumentoTransporte> documentosTransporte;

    @JsonProperty("contenedores")
    private List<Contenedor> contenedores;

    @JsonProperty("links")
    private List<Link> links;


    /******************* GET AND SET ***********************/

    public String getNumCorredoc() {
        return numCorredoc;
    }

    public void setNumCorredoc(String numCorredoc) {
        this.numCorredoc = numCorredoc;
    }

    public Catalogo getAduanaDeclaracion() {
        return aduanaDeclaracion;
    }

    public void setAduanaDeclaracion(Catalogo aduanaDeclaracion) {
        this.aduanaDeclaracion = aduanaDeclaracion;
    }

    public String getNumDeclaracion() {
        return numDeclaracion;
    }

    public void setNumDeclaracion(String numDeclaracion) {
        this.numDeclaracion = numDeclaracion;
    }

    public String getAnnPresen() {
        return annPresen;
    }

    public void setAnnPresen(String annPresen) {
        this.annPresen = annPresen;
    }

    public Catalogo getRegimen() {
        return regimen;
    }

    public void setRegimen(Catalogo regimen) {
        this.regimen = regimen;
    }

    public String getIdDam() {
        return idDam;
    }

    public void setIdDam(String idDam) {
        this.idDam = idDam;
    }

    public String getAnnOrden() {
        return annOrden;
    }

    public void setAnnOrden(String annOrden) {
        this.annOrden = annOrden;
    }

    public String getNumOrden() {
        return numOrden;
    }

    public void setNumOrden(String numOrden) {
        this.numOrden = numOrden;
    }

    public Catalogo getModalidad() {
        return modalidad;
    }

    public void setModalidad(Catalogo modalidad) {
        this.modalidad = modalidad;
    }

    public Catalogo getTipoDespacho() {
        return tipoDespacho;
    }

    public void setTipoDespacho(Catalogo tipoDespacho) {
        this.tipoDespacho = tipoDespacho;
    }

    public Catalogo getTipoLugarRecepcion() {
        return tipoLugarRecepcion;
    }

    public void setTipoLugarRecepcion(Catalogo tipoLugarRecepcion) {
        this.tipoLugarRecepcion = tipoLugarRecepcion;
    }

    public String getCodLocalAnexo() {
        return codLocalAnexo;
    }

    public void setCodLocalAnexo(String codLocalAnexo) {
        this.codLocalAnexo = codLocalAnexo;
    }

    public String getCodTipAduDest() {
        return codTipAduDest;
    }

    public void setCodTipAduDest(String codTipAduDest) {
        this.codTipAduDest = codTipAduDest;
    }

    public String getCodAduDest() {
        return codAduDest;
    }

    public void setCodAduDest(String codAduDest) {
        this.codAduDest = codAduDest;
    }

    public BigDecimal getMtoTotFobDol() {
        return mtoTotFobDol;
    }

    public void setMtoTotFobDol(BigDecimal mtoTotFobDol) {
        this.mtoTotFobDol = mtoTotFobDol;
    }

    public BigDecimal getMtoTotFleteDol() {
        return mtoTotFleteDol;
    }

    public void setMtoTotFleteDol(BigDecimal mtoTotFleteDol) {
        this.mtoTotFleteDol = mtoTotFleteDol;
    }

    public BigDecimal getMtoTotSegDol() {
        return mtoTotSegDol;
    }

    public void setMtoTotSegDol(BigDecimal mtoTotSegDol) {
        this.mtoTotSegDol = mtoTotSegDol;
    }

    public BigDecimal getMtoTotAjustesDol() {
        return mtoTotAjustesDol;
    }

    public void setMtoTotAjustesDol(BigDecimal mtoTotAjustesDol) {
        this.mtoTotAjustesDol = mtoTotAjustesDol;
    }

    public BigDecimal getMtoTotOtrosAjuste() {
        return mtoTotOtrosAjuste;
    }

    public void setMtoTotOtrosAjuste(BigDecimal mtoTotOtrosAjuste) {
        this.mtoTotOtrosAjuste = mtoTotOtrosAjuste;
    }

    public BigDecimal getMtoTotValorAdu() {
        return mtoTotValorAdu;
    }

    public void setMtoTotValorAdu(BigDecimal mtoTotValorAdu) {
        this.mtoTotValorAdu = mtoTotValorAdu;
    }

    public BigDecimal getCntPesoBrutoTotal() {
        return cntPesoBrutoTotal;
    }

    public void setCntPesoBrutoTotal(BigDecimal cntPesoBrutoTotal) {
        this.cntPesoBrutoTotal = cntPesoBrutoTotal;
    }

    public BigDecimal getCntPesoNetoTotal() {
        return cntPesoNetoTotal;
    }

    public void setCntPesoNetoTotal(BigDecimal cntPesoNetoTotal) {
        this.cntPesoNetoTotal = cntPesoNetoTotal;
    }

    public BigDecimal getCntTotBultos() {
        return cntTotBultos;
    }

    public void setCntTotBultos(BigDecimal cntTotBultos) {
        this.cntTotBultos = cntTotBultos;
    }

    public BigDecimal getCntTotSeries() {
        return cntTotSeries;
    }

    public void setCntTotSeries(BigDecimal cntTotSeries) {
        this.cntTotSeries = cntTotSeries;
    }

    public BigDecimal getMtoTotAutoLiq() {
        return mtoTotAutoLiq;
    }

    public void setMtoTotAutoLiq(BigDecimal mtoTotAutoLiq) {
        this.mtoTotAutoLiq = mtoTotAutoLiq;
    }

    public Catalogo getEstadoDeclaracion() {
        return estadoDeclaracion;
    }

    public void setEstadoDeclaracion(Catalogo estadoDeclaracion) {
        this.estadoDeclaracion = estadoDeclaracion;
    }

    public Catalogo getModalidadPago() {
        return modalidadPago;
    }

    public void setModalidadPago(Catalogo modalidadPago) {
        this.modalidadPago = modalidadPago;
    }

    public Catalogo getEntidadPago() {
        return entidadPago;
    }

    public void setEntidadPago(Catalogo entidadPago) {
        this.entidadPago = entidadPago;
    }

    public String getCntPlzCredito() {
        return cntPlzCredito;
    }

    public void setCntPlzCredito(String cntPlzCredito) {
        this.cntPlzCredito = cntPlzCredito;
    }

    public String getFecDocPagoBco() {
        return fecDocPagoBco;
    }

    public void setFecDocPagoBco(String fecDocPagoBco) {
        this.fecDocPagoBco = fecDocPagoBco;
    }

    public String getIndExportTerceros() {
        return indExportTerceros;
    }

    public void setIndExportTerceros(String indExportTerceros) {
        this.indExportTerceros = indExportTerceros;
    }

    public Catalogo getTipoTratamientoMercancia() {
        return tipoTratamientoMercancia;
    }

    public void setTipoTratamientoMercancia(Catalogo tipoTratamientoMercancia) {
        this.tipoTratamientoMercancia = tipoTratamientoMercancia;
    }

    public Catalogo getViaTransporte() {
        return viaTransporte;
    }

    public void setViaTransporte(Catalogo viaTransporte) {
        this.viaTransporte = viaTransporte;
    }

    public Catalogo getTipoManifiesto() {
        return tipoManifiesto;
    }

    public void setTipoManifiesto(Catalogo tipoManifiesto) {
        this.tipoManifiesto = tipoManifiesto;
    }

    public String getCodPuerPreseMani() {
        return codPuerPreseMani;
    }

    public void setCodPuerPreseMani(String codPuerPreseMani) {
        this.codPuerPreseMani = codPuerPreseMani;
    }

    public String getFecTerm() {
        return fecTerm;
    }

    public void setFecTerm(String fecTerm) {
        this.fecTerm = fecTerm;
    }

    public String getFecIniEmbarque() {
        return fecIniEmbarque;
    }

    public void setFecIniEmbarque(String fecIniEmbarque) {
        this.fecIniEmbarque = fecIniEmbarque;
    }

    public String getCodPuerDesp() {
        return codPuerDesp;
    }

    public void setCodPuerDesp(String codPuerDesp) {
        this.codPuerDesp = codPuerDesp;
    }

    public Catalogo getCanalControl() {
        return canalControl;
    }

    public void setCanalControl(Catalogo canalControl) {
        this.canalControl = canalControl;
    }

    public BigDecimal getMtoTotDeudaSol() {
        return mtoTotDeudaSol;
    }

    public void setMtoTotDeudaSol(BigDecimal mtoTotDeudaSol) {
        this.mtoTotDeudaSol = mtoTotDeudaSol;
    }

    public BigDecimal getMtoTotPagado() {
        return mtoTotPagado;
    }

    public void setMtoTotPagado(BigDecimal mtoTotPagado) {
        this.mtoTotPagado = mtoTotPagado;
    }

    public Date getFecDeclaracion() {
        return fecDeclaracion;
    }

    public void setFecDeclaracion(Date fecDeclaracion) {
        this.fecDeclaracion = fecDeclaracion;
    }

    public Date getFecAutLevante() {
        return fecAutLevante;
    }

    public void setFecAutLevante(Date fecAutLevante) {
        this.fecAutLevante = fecAutLevante;
    }

    public Date getFecConclusion() {
        return fecConclusion;
    }

    public void setFecConclusion(Date fecConclusion) {
        this.fecConclusion = fecConclusion;
    }

    public Date getFecRegulariza() {
        return fecRegulariza;
    }

    public void setFecRegulariza(Date fecRegulariza) {
        this.fecRegulariza = fecRegulariza;
    }

    public Date getFecAmpliacion() {
        return fecAmpliacion;
    }

    public void setFecAmpliacion(Date fecAmpliacion) {
        this.fecAmpliacion = fecAmpliacion;
    }

    public String getCodRucLugRecep() {
        return codRucLugRecep;
    }

    public void setCodRucLugRecep(String codRucLugRecep) {
        this.codRucLugRecep = codRucLugRecep;
    }

    public BigDecimal getCntTqUniFis() {
        return cntTqUniFis;
    }

    public void setCntTqUniFis(BigDecimal cntTqUniFis) {
        this.cntTqUniFis = cntTqUniFis;
    }

    public BigDecimal getCntTqUniCom() {
        return cntTqUniCom;
    }

    public void setCntTqUniCom(BigDecimal cntTqUniCom) {
        this.cntTqUniCom = cntTqUniCom;
    }

    public String getCodProdUrgente() {
        return codProdUrgente;
    }

    public void setCodProdUrgente(String codProdUrgente) {
        this.codProdUrgente = codProdUrgente;
    }

    public String getFecFinProvsional() {
        return fecFinProvsional;
    }

    public void setFecFinProvsional(String fecFinProvsional) {
        this.fecFinProvsional = fecFinProvsional;
    }

    public Manifiesto getManifiesto() {
        return manifiesto;
    }

    public void setManifiesto(Manifiesto manifiesto) {
        this.manifiesto = manifiesto;
    }

    public String getNumViaje() {
        return numViaje;
    }

    public void setNumViaje(String numViaje) {
        this.numViaje = numViaje;
    }

    public BigDecimal getMtoFobFactu() {
        return mtoFobFactu;
    }

    public void setMtoFobFactu(BigDecimal mtoFobFactu) {
        this.mtoFobFactu = mtoFobFactu;
    }

    public String getNumCtacte() {
        return numCtacte;
    }

    public void setNumCtacte(String numCtacte) {
        this.numCtacte = numCtacte;
    }

    public Date getFecCarcr() {
        return fecCarcr;
    }

    public void setFecCarcr(Date fecCarcr) {
        this.fecCarcr = fecCarcr;
    }

    public BigDecimal getMtoTotDeudaDol() {
        return mtoTotDeudaDol;
    }

    public void setMtoTotDeudaDol(BigDecimal mtoTotDeudaDol) {
        this.mtoTotDeudaDol = mtoTotDeudaDol;
    }

    public String getIndEscaner() {
        return indEscaner;
    }

    public void setIndEscaner(String indEscaner) {
        this.indEscaner = indEscaner;
    }

    public String getCodMotivoCanalAsig() {
        return codMotivoCanalAsig;
    }

    public void setCodMotivoCanalAsig(String codMotivoCanalAsig) {
        this.codMotivoCanalAsig = codMotivoCanalAsig;
    }

    public Date getFecVencRegula() {
        return fecVencRegula;
    }

    public void setFecVencRegula(Date fecVencRegula) {
        this.fecVencRegula = fecVencRegula;
    }

    public String getIndSocorro() {
        return indSocorro;
    }

    public void setIndSocorro(String indSocorro) {
        this.indSocorro = indSocorro;
    }

    public Date getFecRecep() {
        return fecRecep;
    }

    public void setFecRecep(Date fecRecep) {
        this.fecRecep = fecRecep;
    }

    public Date getFecRereg() {
        return fecRereg;
    }

    public void setFecRereg(Date fecRereg) {
        this.fecRereg = fecRereg;
    }

    public Date getFecVenRegimen() {
        return fecVenRegimen;
    }

    public void setFecVenRegimen(Date fecVenRegimen) {
        this.fecVenRegimen = fecVenRegimen;
    }

    public String getCodDigVeri() {
        return codDigVeri;
    }

    public void setCodDigVeri(String codDigVeri) {
        this.codDigVeri = codDigVeri;
    }

    public Date getFecLlegada() {
        return fecLlegada;
    }

    public void setFecLlegada(Date fecLlegada) {
        this.fecLlegada = fecLlegada;
    }

    public Date getFecSalTerAlm() {
        return fecSalTerAlm;
    }

    public void setFecSalTerAlm(Date fecSalTerAlm) {
        this.fecSalTerAlm = fecSalTerAlm;
    }

    public Date getFecVenConclu() {
        return fecVenConclu;
    }

    public void setFecVenConclu(Date fecVenConclu) {
        this.fecVenConclu = fecVenConclu;
    }

    public String getCodTipoEmbarque() {
        return codTipoEmbarque;
    }

    public void setCodTipoEmbarque(String codTipoEmbarque) {
        this.codTipoEmbarque = codTipoEmbarque;
    }

    public String getCodFormaEmbarque() {
        return codFormaEmbarque;
    }

    public void setCodFormaEmbarque(String codFormaEmbarque) {
        this.codFormaEmbarque = codFormaEmbarque;
    }

    public String getCodPaisDestino() {
        return codPaisDestino;
    }

    public void setCodPaisDestino(String codPaisDestino) {
        this.codPaisDestino = codPaisDestino;
    }

    public String getCodPuertoEmbar() {
        return codPuertoEmbar;
    }

    public void setCodPuertoEmbar(String codPuertoEmbar) {
        this.codPuertoEmbar = codPuertoEmbar;
    }

    public String getCodUltViaTrasla() {
        return codUltViaTrasla;
    }

    public void setCodUltViaTrasla(String codUltViaTrasla) {
        this.codUltViaTrasla = codUltViaTrasla;
    }

    public BigDecimal getMtoClausulaVenta() {
        return mtoClausulaVenta;
    }

    public void setMtoClausulaVenta(BigDecimal mtoClausulaVenta) {
        this.mtoClausulaVenta = mtoClausulaVenta;
    }

    public BigDecimal getMtoComisionVenta() {
        return mtoComisionVenta;
    }

    public void setMtoComisionVenta(BigDecimal mtoComisionVenta) {
        this.mtoComisionVenta = mtoComisionVenta;
    }

    public BigDecimal getMtoGastosDeduc() {
        return mtoGastosDeduc;
    }

    public void setMtoGastosDeduc(BigDecimal mtoGastosDeduc) {
        this.mtoGastosDeduc = mtoGastosDeduc;
    }

    public String getCodCategoria() {
        return codCategoria;
    }

    public void setCodCategoria(String codCategoria) {
        this.codCategoria = codCategoria;
    }

    public Participante getConsignatario() {
        return consignatario;
    }

    public void setConsignatario(Participante consignatario) {
        this.consignatario = consignatario;
    }

    public Participante getAgenteAduana() {
        return agenteAduana;
    }

    public void setAgenteAduana(Participante agenteAduana) {
        this.agenteAduana = agenteAduana;
    }

    public Boolean getEsOEA() {
        return esOEA;
    }

    public void setEsOEA(Boolean esOEA) {
        this.esOEA = esOEA;
    }

    public Boolean getTieneGarantia160() {
        return tieneGarantia160;
    }

    public void setTieneGarantia160(Boolean tieneGarantia160) {
        this.tieneGarantia160 = tieneGarantia160;
    }

    public List<DocumentoTransporte> getDocumentosTransporte() {
        return documentosTransporte;
    }

    public void setDocumentosTransporte(List<DocumentoTransporte> documentosTransporte) {
        this.documentosTransporte = documentosTransporte;
    }

    public List<Contenedor> getContenedores() {
        return contenedores;
    }

    public void setContenedores(List<Contenedor> contenedores) {
        this.contenedores = contenedores;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }
}



