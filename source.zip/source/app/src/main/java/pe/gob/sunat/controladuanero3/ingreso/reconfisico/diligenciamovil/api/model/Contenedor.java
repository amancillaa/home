package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/**
 * Contenedor
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numContenedor",
        "escaner",
        "precintos"
})
public class Contenedor extends BaseModel{


  @JsonProperty("numContenedor")
  private String numContenedor;
  
  @JsonProperty("escaner")
  private String escaner;
  
  @JsonProperty("precintos")
  private List<Precinto> precintos;

  /*** METODOS DE NEGOCIO ***/

  public String getPrecintosConcat() {

    List<String> lst = new ArrayList<>();

    precintos.forEach(precinto -> {
      lst.add(precinto.getNumPrecinto());
    });

    String precintosCommaSeparated = lst.stream()
            .collect(Collectors.joining(","));
    return precintosCommaSeparated;
  }

  /** SET AND GET **/
  public String getNumContenedor() {
    return numContenedor;
  }

  public void setNumContenedor(String numContenedor) {
    this.numContenedor = numContenedor;
  }

  public String getEscaner() {
    return escaner;
  }

  public void setEscaner(String escaner) {
    this.escaner = escaner;
  }

  public List<Precinto> getPrecintos() {
    return precintos;
  }


  public void setPrecintos(List<Precinto> precintos) {
    this.precintos = precintos;
  }
}



