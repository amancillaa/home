package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.CardView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.SplashActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ActivityManagerUtil;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Session;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;


public abstract class BaseActivity extends AppCompatActivity {

    private static final String TAG = BaseActivity.class.getSimpleName();

    @Inject
    protected Session session;

    @BindView(R.id.loading)
    protected LinearLayout loading;
    @BindView(R.id.nofound)
    protected LinearLayout noFound;

    protected Unbinder unbinder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutId());
        unbinder = ButterKnife.bind(this);
    }

    protected abstract int getLayoutId();

    @Override
    protected void onDestroy() {
        unbinder.unbind();
        super.onDestroy();
        ActivityManagerUtil.finishAllActivity();
    }

    public void goLogin(){
        session.logout();
        Intent intentStart = new Intent(getApplicationContext(), SplashActivity.class);
        intentStart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intentStart);
        finish();
    }

    public void showSuccessMessage(String successMessage){
        Toast toast = new Toast(this);
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText(successMessage);
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_done);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.green_500));

        toast.setView(custom_view);
        toast.show();
    }

    public void showErrorMessage(String errorMessage){

        Toast toast = new Toast(this);
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText(errorMessage);
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_close);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.red_600));

        toast.setView(custom_view);
        toast.show();
    }

    public void showInfoMessage(String infoMessage) {
        Toast toast = new Toast(this);
        toast.setDuration(Toast.LENGTH_LONG);

        //inflate view
        View custom_view = getLayoutInflater().inflate(R.layout.toast_icon_text, null);
        ((TextView) custom_view.findViewById(R.id.message)).setText(infoMessage);
        ((ImageView) custom_view.findViewById(R.id.icon)).setImageResource(R.drawable.ic_error_outline);
        ((CardView) custom_view.findViewById(R.id.parent_view)).setCardBackgroundColor(getResources().getColor(R.color.blue_500));

        toast.setView(custom_view);
        toast.show();
    }

    public boolean isConnected(){
        return Tools.isConnected(this);
    }

    public boolean isAirplaneModeOff(){
        return Tools.isAirplaneModeOff(this);
    }

    public void showLoading() {
        hideMessage();
        loading.setVisibility(View.VISIBLE);
    }

    public void hideMessage() {
        noFound.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
    }

    public void showNoFound() {
        hideMessage();
        noFound.setVisibility(View.VISIBLE);
    }

    public void hideLoading() {
        loading.setVisibility(View.GONE);
    }


    public void showLogoutDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_logout);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        ((AppCompatButton) dialog.findViewById(R.id.bt_no)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

        ((AppCompatButton) dialog.findViewById(R.id.bt_si)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goLogin();
            }
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    public void showTokenDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_token);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        ((AppCompatButton) dialog.findViewById(R.id.bt_aceptar)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goLogin();
            }
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }


    public void showSuccesDialog(String idDam) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_exito);
        dialog.setCancelable(true);

        if(!idDam.isEmpty()){
            ((TextView)(dialog.findViewById(R.id.title))).setText("DAM : "+idDam);
        }

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                irBandeja();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }



    public void showWarningDialog(List<String> lstAdvertencias, String idDam, String tipo){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_advertencias);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        ((TextView)(dialog.findViewById(R.id.idDam))).setText(idDam);

        String textoAdvertencias = lstAdvertencias.stream().collect(Collectors.joining("\n"));

        ((TextView)(dialog.findViewById(R.id.advertencias))).setText(textoAdvertencias);

        (dialog.findViewById(R.id.bt_close)).setOnClickListener((View v) -> dialog.dismiss());
        if(!Arrays.asList(new String[]{Constantes.ARG_TIPO_ADVERTENCIA_BANDEJA}).contains(tipo)){
            ((Button)dialog.findViewById(R.id.bt_Continuar)).setText("Aceptar");
        }

        (dialog.findViewById(R.id.bt_Continuar)).setOnClickListener((View v) -> {
            dialog.dismiss();
            if(Arrays.asList(new String[]{Constantes.ARG_TIPO_ADVERTENCIA_BANDEJA}).contains(tipo)){
                Bundle bundle = new Bundle();
                bundle.putString(Constantes.ARG_IDDAM,idDam);
                irDeclaracion(bundle);
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    protected abstract void irDeclaracion(Bundle bundle);

    protected abstract void irBandeja();
}
