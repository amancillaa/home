package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

/**
 * DocumentoTransporte
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numDocTransp"
})
public class DocumentoTransporte extends BaseModel implements Serializable {


    private static final long serialVersionUID = 8799656478674716638L;

  @JsonProperty("numDocTransp")
  private String numDocTransp;

    public String getNumDocTransp() {
        return numDocTransp;
    }

    public void setNumDocTransp(String numDocTransp) {
        this.numDocTransp = numDocTransp;
    }
}



