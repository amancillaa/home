package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class Session {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    Context ctx;
    ContentResolver resolver;

    private static String TAG = Session.class.getSimpleName();
    /** DATOS DEL CLIENT AUTENTICAR **/
    public static final String CLIENT_ID_SUNAT     = "client_id_sunat";
    public static final String CLIENT_SECRET_SUNAT = "client_secret_sunat";
    /** DATOS PRVENIENTES DEL TOKEN **/
    public static final String SUNAT_TOKEN         = "sunat_token";
    public static final String SUNAT_COD_UO        = "sunat_cod_uo";
    public static final String NOMBRE_COMPLETO     = "nombre_completo";
    public static final String SUNAT_CORREO        = "sunat_correo";
    public static final String SUNAT_COD_FUNCIONARIO = "sunat_cod_funcionario";
    public static final String SUNAT_USUARIO         = "sunat_usuario";
    /** MANEJO DE LOGIN **/
    public static final String PREF_NAME           = "appDiligenciaMovil";
    public static final String KEY_IS_LOGGEDIN     = "isLoggedIn";

    /** CONSTRUCTOR **/
    @Inject
    public Session(Context ctx){
        this.ctx = ctx;
        prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
        resolver = ctx.getContentResolver();
    }

    /** METODOS DE NEGOCIO **/

    public String getTitulo(String tipo){

        String titulo = "---";
        if(Constantes.ARG_TITULO_BANDEJA.equals(tipo)){
            titulo = "BANDEJA: ".concat(getUsuario());
        }else if(Constantes.ARG_TITULO_DAM.equals(tipo)){
            titulo = "DAM: ".concat(getIdDAM());
        }else if(Constantes.ARG_TITULO_DOCUTRANS.equals(tipo)){
            titulo = "Listado Doc. de Transporte";
        }else if(Constantes.ARG_TITULO_CONTENEDORES.equals(tipo)){
            titulo = "Listado de Contenedores";
        }else if(Constantes.ARG_TITULO_SERIE.equals(tipo)) {
            titulo = "SERIE: ".concat(getIdSERIE());
        }else if(Constantes.ARG_TITULO_SERIES.equals(tipo)) {
            titulo = "Listado de Series";
        }else if(Constantes.ARG_TITULO_ITEM.equals(tipo)){
            titulo = "ITEM: ".concat(getIdITEM());
        }else if(Constantes.ARG_TITULO_ITEMS.equals(tipo)){
            titulo = "Listado de Items";
        }else if(Constantes.ARG_TITULO_DILIGENCIA.equals(tipo)){
            titulo = "Registrar Diligencia";
        }else if(Constantes.ARG_TITULO_RIESGO.equals(tipo)){
            titulo = "Indicadores de Riesgo";
        }else if(Constantes.ARG_TITULO_DEUDA.equals(tipo)){
            titulo = "Deuda Tributaria";
        }else if(Constantes.ARG_TITULO_LCS.equals(tipo)){
            titulo = "Listado LCs";
        }

        return titulo;
    }

    public void setClientIdSunat(String client_id_sunat){
        prefs.edit().putString(Session.CLIENT_ID_SUNAT,client_id_sunat).apply();
    }

    public void setClientSecretSunat(String client_secret_sunat){
        prefs.edit().putString(Session.CLIENT_SECRET_SUNAT,client_secret_sunat).apply();
    }

    public String getClientIdSunat(){
        return prefs.getString(CLIENT_ID_SUNAT,"");
    }

    public String getClientSecretSunat(){
        return prefs.getString(CLIENT_SECRET_SUNAT,"");
    }

    public String getNombreCompleto() {
        return prefs.getString(NOMBRE_COMPLETO,"");
    }

    public void setNombreCompleto(String nombre_completo) {
        editor.putString(Session.NOMBRE_COMPLETO, nombre_completo);
        editor.commit();
    }

    public String getCorreo() {

        return prefs.getString(SUNAT_CORREO,"");
    }

    public void setCorreo(String sunat_correo) {

        editor.putString(SUNAT_CORREO, sunat_correo);
        editor.commit();
    }

    public String getToken() {

        return prefs.getString(SUNAT_TOKEN,"");
    }

    public void setToken(String sunat_token) {

        editor.putString(SUNAT_TOKEN, sunat_token);
        editor.commit();

        setLogin(true);
    }

    public String getCodArea() {

        return prefs.getString(SUNAT_COD_UO,"");
    }

    public void setCodArea(String sunat_cod_uo) {

        editor.putString(SUNAT_COD_UO, sunat_cod_uo);
        editor.commit();
    }

    public String getCodFuncionario() {

        return prefs.getString(SUNAT_COD_FUNCIONARIO,"");
    }

    public void setCodFuncionario(String sunat_cod_funcionario) {

        editor.putString(SUNAT_COD_FUNCIONARIO, sunat_cod_funcionario);
        editor.commit();
    }

    public String getUsuario() {

        return prefs.getString(SUNAT_USUARIO,"");
    }

    public void setUsuario(String sunat_usuario) {

        editor.putString(SUNAT_USUARIO, sunat_usuario);
        editor.commit();
    }


    public String getIdDAM() {

        return prefs.getString(Constantes.ARG_IDDAM,"");
    }

    public void setIdDAM(String idDam) {

        editor.putString(Constantes.ARG_IDDAM, idDam);
        editor.commit();
    }

    public String getFecNumeracion() {

        return prefs.getString(Constantes.FEC_RECEP,"");
    }

    public void setFecNumeracion(String dateISO) {

        editor.putString(Constantes.FEC_RECEP, dateISO);
        editor.commit();
    }

    public String getNavegacion() {

        return prefs.getString(Constantes.NAVEGACION,"");
    }

    public void setNavegacion(Navegacion navegacion) {

        editor.putString(Constantes.NAVEGACION, navegacion.name());
        editor.commit();
    }

    public String getIdSERIE() {

        return prefs.getString(Constantes.ARG_IDSERIE,"");
    }

    public void setIdSERIE(String numSecSerie) {

        editor.putString(Constantes.ARG_IDSERIE, numSecSerie);
        editor.commit();
    }

    public String getIdITEM() {

        return prefs.getString(Constantes.ARG_IDITEM,"");
    }

    public void setIdITEM(String numSecItem) {

        editor.putString(Constantes.ARG_IDITEM, numSecItem);
        editor.commit();
    }
    public void setLogin(boolean isLoggedIn){
        editor.putBoolean(KEY_IS_LOGGEDIN,isLoggedIn);
        editor.commit();
    }

    public boolean isLoggedIn(){
        return prefs.getBoolean(KEY_IS_LOGGEDIN, false);
    }


    public void logout() {
        setLogin(false);
        blanquearToken();
        editor.remove(CLIENT_ID_SUNAT);
        editor.remove(CLIENT_SECRET_SUNAT);
        editor.remove(SUNAT_TOKEN);
        editor.remove(SUNAT_COD_UO);
        editor.remove(NOMBRE_COMPLETO);
        editor.remove(SUNAT_CORREO);
        editor.remove(SUNAT_COD_FUNCIONARIO);
        editor.remove(Constantes.ARG_IDDAM);
        editor.remove(Constantes.ARG_IDSERIE);
        editor.remove(Constantes.ARG_IDITEM);
        editor.remove(Constantes.FEC_RECEP);
        editor.remove(Constantes.NAVEGACION);
        editor.commit();

    }

    private void blanquearToken() {
        ContentValues conValues = new ContentValues();
        String selectionClause = " usuario = ?";
        String[] selectionArgs = {getUsuario()};
        conValues.put("token","");
        int rowsUpdated = resolver.update(Constantes.CONTENT_URI, conValues, selectionClause, selectionArgs);
    }



}

