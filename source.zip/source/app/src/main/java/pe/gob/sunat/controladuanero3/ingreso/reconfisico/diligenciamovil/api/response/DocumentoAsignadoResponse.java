package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class DocumentoAsignadoResponse extends BaseResponse {

    private DocumentosAsignados documentosAsignados;

    public DocumentoAsignadoResponse(DocumentosAsignados documentosAsignados) {
        this.error = null;
        this.errorGeneral = null;
        this.documentosAsignados = documentosAsignados;
    }

    public DocumentoAsignadoResponse(ErrorGeneral errorGeneral) {
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.documentosAsignados = null;
    }

    public DocumentoAsignadoResponse(Throwable error) {
        this.error = error;
        this.errorGeneral = null;
        this.documentosAsignados = null;
    }

    public DocumentosAsignados getDocumentosAsignados() {
        return documentosAsignados;
    }

    public void setDocumentosAsignados(DocumentosAsignados documentosAsignados) {
        this.documentosAsignados = documentosAsignados;
    }
}
