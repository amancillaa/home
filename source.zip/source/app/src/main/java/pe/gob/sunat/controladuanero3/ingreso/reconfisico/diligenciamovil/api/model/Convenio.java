package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tipConvenio",
        "codConvenio"
})
public class Convenio {
    @JsonProperty("tipConvenio")
    private String tipConvenio;
    @JsonProperty("codConvenio")
    private String codConvenio;

    public Convenio(){
        this.codConvenio = "";
        this.tipConvenio = "";
    }
    public String getTipConvenio() {
        return tipConvenio;
    }

    public void setTipConvenio(String tipConvenio) {
        this.tipConvenio = tipConvenio;
    }

    public String getCodConvenio() {
        return codConvenio;
    }

    public void setCodConvenio(String codConvenio) {
        this.codConvenio = codConvenio;
    }
}
