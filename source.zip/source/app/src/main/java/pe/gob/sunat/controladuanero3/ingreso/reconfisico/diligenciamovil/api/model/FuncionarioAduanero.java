
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * recurso funcionario aduanero
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codFuncionario",
        "apePaterno",
        "apeMaterno",
        "nombres",
        "nombreCompleto",
        "area",
        "links"
})
public class FuncionarioAduanero {


    @JsonProperty("codFuncionario")
    private String codFuncionario;

    @JsonProperty("apePaterno")
    private String apePaterno;

    @JsonProperty("apeMaterno")
    private String apeMaterno;

    @JsonProperty("nombres")
    private String nombres;

    @JsonProperty("nombreCompleto")
    private String nombreCompleto;

    @JsonProperty("area")
    private Catalogo area;

    @JsonProperty("links")
    private List<Link> links;

    public String getCodFuncionario() {
        return codFuncionario;
    }

    public void setCodFuncionario(String codFuncionario) {
        this.codFuncionario = codFuncionario;
    }

    public String getApePaterno() {
        return apePaterno;
    }

    public void setApePaterno(String apePaterno) {
        this.apePaterno = apePaterno;
    }

    public String getApeMaterno() {
        return apeMaterno;
    }

    public void setApeMaterno(String apeMaterno) {
        this.apeMaterno = apeMaterno;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public Catalogo getArea() {
        return area;
    }

    public void setArea(Catalogo area) {
        this.area = area;
    }

    public List<Link> getLinks() {
        return links;
    }

    public void setLinks(List<Link> links) {
        this.links = links;
    }
}



