package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;



public class BaseModel {

    //protected int image;
    //protected Drawable imageDrw;
    //protected String descripcion;
    protected boolean expanded = false;
    //protected boolean parent = false;
    //protected boolean swiped = false;


    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }
}
