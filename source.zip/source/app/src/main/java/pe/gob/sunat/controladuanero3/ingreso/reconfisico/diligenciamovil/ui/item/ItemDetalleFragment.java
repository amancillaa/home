package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.item;


import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import butterknife.BindView;

import dagger.android.support.AndroidSupportInjection;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Item;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di.Injectable;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.BaseFragment;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.main.MainActivity;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel.ItemViewModel;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import timber.log.Timber;


public class ItemDetalleFragment extends BaseFragment implements Injectable {

    public static final String TAG = ItemDetalleFragment.class.getSimpleName();

    @Inject
    ViewModelProvider.Factory viewModelFactory;

    @BindView(R.id.text_view_partida)
    TextView textViewPartida;
    @BindView(R.id.text_view_descripcion_mercancia)
    TextView textViewDescripcionMercancia;
    @BindView(R.id.text_view_proveedor)
    TextView textViewProveedor;
    @BindView(R.id.text_view_cant_unid_camercial)
    TextView textViewCantUnidCamercial;
    @BindView(R.id.text_view_num_factura)
    TextView textViewNumFactura;
    @BindView(R.id.text_view_fob_unitario)
    TextView textViewFobUnitario;
    @BindView(R.id.text_view_fecha_factura)
    TextView textViewFechaFactura;


    private View view;
    private OnFragmentIterationListener listener;
    private ItemViewModel viewModel;


    public interface OnFragmentIterationListener {
        void setItemDetalleFragment(Bundle bundle);
    }

    public ItemDetalleFragment() {
    }

    public static ItemDetalleFragment newInstance(Bundle params) {
        ItemDetalleFragment idf = new ItemDetalleFragment();
        idf.setArguments(params);
        return idf;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this,viewModelFactory).get(ItemViewModel.class);

        Bundle params = getArguments();

        String token = params.getString(Constantes.ARG_TOKEN);
        String idDam = params.getString(Constantes.ARG_IDDAM);
        String idSerie = params.getString(Constantes.ARG_IDSERIE);
        String idItem = params.getString(Constantes.ARG_IDITEM);

        viewModel.getItem(token,idDam,idSerie,idItem).observe(this,response -> {

            ((MainActivity)getActivity()).hideMessage();
            Item item = response.getItem();
            ErrorGeneral error  = response.getErrorGeneral();
            Throwable throwable = response.getError();

            if(item!=null){
                cargarPantalla(item);
            }else if(error != null){

                String errorMsg = error.getCod().concat(":").concat(error.getMsg()+"->").concat(error.getExc());

                if(Constantes.ERROR_TOKEN_INVALIDO.equals(error.getCod())){
                    Timber.w(errorMsg);
                    ((BaseActivity)getActivity()).showTokenDialog();
                }else {
                    Timber.e(errorMsg);
                    ((BaseActivity)getActivity()).showErrorMessage(errorMsg);
                }
            }else if (throwable != null) {
                Timber.e(throwable.getMessage());
                ((BaseActivity)getActivity()).showErrorMessage(throwable.getMessage());
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle state) {
        super.onActivityCreated(state);
        initComponent();
    }

    private void initComponent() {
        Bundle params = getArguments();
        setSubTitulo(params.getString(Constantes.SUB_TITULO));
    }

    private void cargarPantalla(Item item) {

        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator(',');
        symbols.setDecimalSeparator('.');
        DecimalFormat decimalFormat = new DecimalFormat("US$ #,###.00", symbols);
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        textViewPartida.setText(item.getNumParArancel());
        textViewDescripcionMercancia.setText(item.getDesComer()+"-"+item.getDesMarca()+"-"+item.getDesModelo());
        textViewProveedor.setText(item.getFactura().getProveedor().getRucRazonSocial());
        textViewCantUnidCamercial.setText(item.getCntUni().toString().concat(" ").concat(item.getUnidadComercial().getCodDesc()));
        textViewNumFactura.setText(item.getFactura().getNumFactura());
        textViewFobUnitario.setText(decimalFormat.format(item.getMtoFobItem()).toString());
        if(item.getFactura().getFecFact()!=null){
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            try{
               Date date = format.parse(item.getFactura().getFecFact());
               textViewFechaFactura.setText(formatter.format(date));
            }catch (Exception e){
                Log.e(TAG, "Error al cambiar formato fecha factura del item"+item.getNumSecItem());
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_item_detalle, container, false);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        AndroidSupportInjection.inject(this);
        super.onAttach(context);
        if (context instanceof OnFragmentIterationListener) {
            listener = (OnFragmentIterationListener) context;
        } else {
            Log.e(TAG, "El Activity debe implementar la interfaz onFragmentIterationListener");
            throw new RuntimeException(context.toString() + " El Activity debe implementar la interfaz onFragmentIterationListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
