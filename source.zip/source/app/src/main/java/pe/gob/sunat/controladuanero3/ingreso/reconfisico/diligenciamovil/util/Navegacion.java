package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util;

public enum Navegacion {
    DEUDA,
    RIESGO,
    BANDEJA,
    DAM,
    SERIE,
    DILIGENCIA
}
