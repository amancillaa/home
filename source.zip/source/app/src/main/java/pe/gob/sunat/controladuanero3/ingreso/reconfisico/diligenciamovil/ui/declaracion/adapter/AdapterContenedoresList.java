package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.declaracion.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Contenedor;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;

public class AdapterContenedoresList extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Contenedor> contenedores;
    private Context ctx;
    private int animation_type = 0;

    public AdapterContenedoresList(Context ctx, List<Contenedor> contenedores, int animation_type) {
        this.contenedores = contenedores;
        this.ctx = ctx;
        this.animation_type = animation_type;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_contenedores_list, parent,false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof OriginalViewHolder) {
            final OriginalViewHolder view = (OriginalViewHolder)holder;

            final Contenedor contenedor =contenedores.get(position);
            view.numContenedor.setText(contenedor.getNumContenedor());

            view.precintos.setText( contenedor.getPrecintosConcat());

            view.escaner.setText(contenedor.getEscaner());

            view.bt_expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean show = toggleLayoutExpand(!contenedor.isExpanded(), v, view.lyt_expand);
                    contenedores.get(position).setExpanded(show);
                }
            });

            if(contenedor.isExpanded()){
                view.lyt_expand.setVisibility(View.VISIBLE);
            } else {
                view.lyt_expand.setVisibility(View.GONE);
            }
            Tools.toggleArrow(contenedor.isExpanded(), view.bt_expand, false);

            setAnimation(holder.itemView, position);
        }

    }

    @Override
    public int getItemCount() {
        return contenedores.size();
    }

    private class OriginalViewHolder extends RecyclerView.ViewHolder {

        public TextView numContenedor,precintos,escaner;
        public ImageButton bt_expand;
        public View lyt_expand;


        public OriginalViewHolder(View v) {
            super(v);

            numContenedor = (TextView) v.findViewById(R.id.text_view_num_contenedor);
            bt_expand = (ImageButton) v.findViewById(R.id.bt_expand_contenedores);
            lyt_expand = (View) v.findViewById(R.id.lyt_expand_contenedores);
            precintos = v.findViewById(R.id.text_view_precintos);
            escaner = v.findViewById(R.id.text_view_escanner);
        }
    }

    private boolean toggleLayoutExpand(boolean show, View view, View lyt_expand) {
        Tools.toggleArrow(show, view);
        if (show) {
            ViewAnimation.expand(lyt_expand);
        } else {
            ViewAnimation.collapse(lyt_expand);
        }
        return show;
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}
