package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository;


import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.inject.Inject;
import javax.inject.Singleton;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DeudaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DiligenciaResponse;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.service.DiligenciaApi;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;

@Singleton
public class DiligenciaRepository {

    private final static String TAG = DiligenciaRepository.class.getSimpleName();
    private DiligenciaApi diligenciaApi;

    @Inject
    public DiligenciaRepository(DiligenciaApi diligenciaApi) {
        this.diligenciaApi = diligenciaApi;

    }


    public LiveData<DiligenciaResponse> registrarDiligencia(String token, Diligencia diligencia,String idDam) {

        final MutableLiveData<DiligenciaResponse> diligenciaResponse = new MutableLiveData<>();

        diligenciaApi.registrarDiligencia("Bearer " + token, diligencia,idDam).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {

                if (response.isSuccessful()) {
                    diligenciaResponse.postValue(new DiligenciaResponse(diligencia,idDam));
                }
                else if (Constantes.ERROR_VALIDACION.equals(response.code()+"")){

                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(response.code());
                    try {
                        ObjectMapper mapper = new ObjectMapper();
                        errorGeneral = mapper.readValue(response.errorBody().string(), ErrorGeneral.class);
                        errorGeneral.setExc(response.toString());

                        }catch (Exception e){
                            errorGeneral.setMsg(e.getMessage());
                            errorGeneral.setExc(e.getStackTrace().toString());
                        }

                        diligenciaResponse.postValue(new DiligenciaResponse(errorGeneral));

                }else {
                    ErrorGeneral errorGeneral = new ErrorGeneral();
                    errorGeneral.setCod(response.code());
                    errorGeneral.setMsg(response.message());
                    errorGeneral.setExc(response.toString());
                    diligenciaResponse.postValue(new DiligenciaResponse(errorGeneral));
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                diligenciaResponse.postValue(new DiligenciaResponse(t));
            }
        });

        return diligenciaResponse;
    }
}
