package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;


import okhttp3.ResponseBody;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class FotoResponse extends BaseResponse {

    private ResponseBody responseBody;
    private String codFuncionario;

    /**** CONSTRUCTIRES ***/
    public FotoResponse(ResponseBody responseBody, String codFuncionario){
        this.error = null;
        this.errorGeneral = null;
        this.responseBody = responseBody;
        this.codFuncionario = codFuncionario;
    }

    public FotoResponse(ErrorGeneral errorGeneral){
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.responseBody = null;
        this.codFuncionario = null;
    }

    public FotoResponse(Throwable error){
        this.error = error;
        this.errorGeneral = null;
        this.responseBody = null;
        this.codFuncionario = null;
    }

    /****SET AND GET***/
    public ResponseBody getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(ResponseBody responseBody) {
        this.responseBody = responseBody;
    }

    public String getCodFuncionario() {
        return codFuncionario;
    }

    public void setCodFuncionario(String codFuncionario) {
        this.codFuncionario = codFuncionario;
    }
}
