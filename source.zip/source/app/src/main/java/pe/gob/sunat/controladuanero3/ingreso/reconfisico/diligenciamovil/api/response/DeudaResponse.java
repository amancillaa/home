package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DeudaTributaria;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class DeudaResponse extends BaseResponse{
    private DeudaTributaria deudaTributaria;
    private String idDam;

    /*** CONSTRUCTORES ***/
    public DeudaResponse(DeudaTributaria deudaTributaria, String idDam) {
        this.deudaTributaria = deudaTributaria;
        this.idDam = idDam;
        this.error = null;
        this.errorGeneral = null;
    }

    public DeudaResponse(Throwable error) {
        this.error = error;
        this.deudaTributaria = null;
        this.errorGeneral = null;
    }

    public DeudaResponse(ErrorGeneral errorGeneral) {
        this.errorGeneral = errorGeneral;
        this.error = null;
        this.deudaTributaria = null;
    }

    /***SET AND GET***/
    public String getIdDam() {
        return idDam;
    }


    public DeudaTributaria getDeudaTributaria() {
        return deudaTributaria;
    }


}
