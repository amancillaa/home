
package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * Documento que identifica la transferencia de un bien o valor de una persona , entidad  a favor de otra persona o entidad
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numSecfact",
        "proveedor",
        "fecFact",
        "mtoFact",
        "numFactura"
})
public class Factura {


    @JsonProperty("numSecfact")
    private String numSecfact;

    @JsonProperty("proveedor")
    private Proveedor proveedor;

    @JsonProperty("fecFact")
    private String fecFact;

    @JsonProperty("mtoFact")
    private String mtoFact;

    @JsonProperty("numFactura")
    private String numFactura;


    public String getNumSecfact() {
        return numSecfact;
    }

    public void setNumSecfact(String numSecfact) {
        this.numSecfact = numSecfact;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public String getFecFact() {
        return fecFact;
    }

    public void setFecFact(String fecFact) {
        this.fecFact = fecFact;
    }

    public String getMtoFact() {
        return mtoFact;
    }

    public void setMtoFact(String mtoFact) {
        this.mtoFact = mtoFact;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(String numFactura) {
        this.numFactura = numFactura;
    }
}



