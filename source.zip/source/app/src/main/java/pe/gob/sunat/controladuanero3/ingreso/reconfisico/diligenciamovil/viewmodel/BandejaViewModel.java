package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;


import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;

import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.AdvertenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DocumentoAsignadoResponse;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.AsignacionRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Constantes;
import timber.log.Timber;

public class BandejaViewModel extends AndroidViewModel {

    public static final String TAG = BandejaViewModel.class.getSimpleName();


    private LiveData<DocumentoAsignadoResponse> documentoAsignadoResponse;
    private LiveData<AdvertenciaResponse> advertenciaResponse;

    private AsignacionRepository asignacionRepository;
    private DamRepository damRepository;

    @Inject
    public BandejaViewModel(
            @NonNull Application application,
            @NonNull AsignacionRepository asignacionRepository,
            @NonNull DamRepository damRepository
            ) {
        super(application);

        this.asignacionRepository = asignacionRepository;
        this.damRepository = damRepository;

        advertenciaResponse = new MediatorLiveData<>();
        documentoAsignadoResponse = new MediatorLiveData<>();
    }

    public LiveData<DocumentoAsignadoResponse> getListaDocumentosAsignados (String token, String codFuncionario){

        if(documentoAsignadoResponse.getValue() ==null){
            //documentoAsignadoResponse.addSource(asignacionRepository.getListDocumentosAsignados(token, codFuncionario),docAsigResponse->documentoAsignadoResponse.setValue(docAsigResponse));
            documentoAsignadoResponse = asignacionRepository.getListDocumentosAsignados(token, codFuncionario);
        }
        Timber.d("getListaDocumentosAsignados(codFuncionario:%s)->response(%s)",codFuncionario,documentoAsignadoResponse.getValue());
        return documentoAsignadoResponse;
    }

    public LiveData<AdvertenciaResponse> getListaAdvertencias(String token, String idDam, String tipo) {

        String pk = idDam.concat("-").concat(tipo);

        if (advertenciaResponse.getValue() == null
                || !pk.equals(advertenciaResponse.getValue().getPk())) {

            //advertenciaResponse.addSource(damRepository.getAdvertencias(token, idDam, tipo), advResponse -> advertenciaResponse.setValue(advResponse));
            advertenciaResponse = damRepository.getAdvertencias(token, idDam, tipo);
        }
        Timber.d("getListaAdvertencias(idDam:%s,tipo:%s)->response(%s)",idDam,tipo,advertenciaResponse.getValue());
        return advertenciaResponse;
    }
}
