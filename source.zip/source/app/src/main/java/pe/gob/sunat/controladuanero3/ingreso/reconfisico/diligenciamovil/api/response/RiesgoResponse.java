package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import java.util.List;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Riesgo;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class RiesgoResponse extends BaseResponse {
    private List<Riesgo> riesgos;
    private String idDam;


    public RiesgoResponse(List<Riesgo> Riesgos, String idDam) {
        this.error = null;
        this.errorGeneral = null;
        this.riesgos = Riesgos;
        this.idDam = idDam;
    }

    public RiesgoResponse(ErrorGeneral errorGeneral) {
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.riesgos = null;
    }

    public RiesgoResponse(Throwable error) {
        this.error = error;
        this.errorGeneral = null;
        this.riesgos = null;
    }


    /***SET AND GET***/

    public List<Riesgo> getRiesgos() {
        return riesgos;
    }

    public String getIdDam() {
        return idDam;
    }

}
