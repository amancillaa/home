package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class BaseResponse {

    protected Throwable error;
    protected ErrorGeneral errorGeneral;

    /*** SET AND GET ***/
    public Throwable getError() {
        return error;
    }

    public void setError(Throwable error) {
        this.error = error;
    }

    public ErrorGeneral getErrorGeneral() {
        return errorGeneral;
    }

    public void setErrorGeneral(ErrorGeneral errorGeneral) {
        this.errorGeneral = errorGeneral;
    }
}
