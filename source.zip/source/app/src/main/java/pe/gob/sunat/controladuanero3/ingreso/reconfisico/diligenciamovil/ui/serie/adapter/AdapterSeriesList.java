package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.serie.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Convenio;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Series;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Serie;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;

public class AdapterSeriesList extends RecyclerView.Adapter<RecyclerView.ViewHolder>  implements Filterable {


    private Series series;
    private Context ctx;
    private OnItemClickListener mOnItemClickListener;
    private int animation_type = 0;

    public interface OnItemClickListener {
        void onItemClick(View view, Serie obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }


    public AdapterSeriesList(Context context, Series series, int animation_type) {
        this.series = series;
        this.series.setSeriesFiltradas(series.getSeries());//para el filtrado
        ctx = context;
        this.animation_type = animation_type;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_series_list, parent, false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof OriginalViewHolder) {
            final OriginalViewHolder view = (OriginalViewHolder) holder;

            final Serie serie = series.getSeriesFiltradas().get(position);
            //view.name.setText(serie.getNumSerie());
            view.numSecSerie.setText(serie.getNumSecSerie().concat(": ").concat(serie.getDescripcion()));
            view.partida.setText(serie.getNumPartNandi());//SPN
            view.numSecSerie.setText(serie.getNumSecSerie());
            view.descripcion.setText(serie.getDescripcion());
            view.partida.setText(serie.getNumPartNandi());

            view.lyt_parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onItemClick(view, serie, position);
                    }
                }
            });

            view.bt_expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean show = toggleLayoutExpand(!serie.isExpanded(), v, view.lyt_expand);
                    series.getSeriesFiltradas().get(position).setExpanded(show);
//                    series.getSeries().get(position).setExpanded(show);
                }
            });



            if(serie.isExpanded()){
                view.lyt_expand.setVisibility(View.VISIBLE);
            } else {
                view.lyt_expand.setVisibility(View.GONE);
            }
            Tools.toggleArrow(serie.isExpanded(), view.bt_expand, false);
            setAnimation(holder.itemView, position);
        }
    }

    private boolean toggleLayoutExpand(boolean show, View view, View lyt_expand) {
        Tools.toggleArrow(show, view);
        if (show) {
            ViewAnimation.expand(lyt_expand);
        } else {
            ViewAnimation.collapse(lyt_expand);
        }
        return show;
    }


    public void addItems(Series series){
        this.series = series;
        this.series.setSeriesFiltradas(series.getSeries());//para el filtrado
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {

        return  series.getSeries()!=null?series.getSeriesFiltradas().size():0;
    }

  @Override
    public Filter getFilter() {
      return new Filter() {
          @Override
          protected FilterResults performFiltering(CharSequence charSequence) {
              String charString = charSequence.toString();
              String hint = !charString.isEmpty() && charString.contains(":")?
                                charString.substring(0,charString.indexOf(":")):"";

              if(!hint.isEmpty()) {
                  charString = charString.substring(charString.indexOf(":") + 1);
              }

              if (charString.isEmpty()) {
                  series.setSeriesFiltradas(series.getSeries());
              } else {
                  List<Serie> lstSeriesPorQuery = new ArrayList<>();

                  for (Serie serie : series.getSeries()) {

                      if(hint.equals("DESCRIPCION")) hint="";
                      String valorComparacion = obtenerValorComparador(hint, serie);

                      if (valorComparacion.contains(charString.toLowerCase())) {
                          lstSeriesPorQuery.add(serie);
                      }
                  }
                  if(hint.isEmpty() && lstSeriesPorQuery.size()==0){
                      series.setSeriesFiltradas(series.getSeries());
                  }else {
                  series.setSeriesFiltradas(lstSeriesPorQuery);
              }
              }

              FilterResults filterResults = new FilterResults();
              filterResults.values = series.getSeriesFiltradas();
              return filterResults;
          }

          @Override
          protected void publishResults(CharSequence constraint, FilterResults filterResults) {
              series.setSeriesFiltradas((List<Serie>) filterResults.values);
              notifyDataSetChanged();
          }
      };
  }


  public String obtenerValorComparador(String hint, Serie serie){
        String valorComparacion = "";
      if(hint.equals("PARTIDA")){
          valorComparacion = serie.getNumPartNandi().toLowerCase();
      }else if(hint.equals("NRO SERIE")){
          valorComparacion = serie.getNumSecSerie().toLowerCase();
      }else if(hint.equals("FOB")){
          valorComparacion = serie.getMtoFobDol().toString();
      }else if(hint.equals("COD.LIBERATORIO")){
          valorComparacion = convenioFiltrado(serie.getConvenios(),"C").getCodConvenio();
      }else if(hint.equals("TPI")){
          valorComparacion = convenioFiltrado(serie.getConvenios(),"I").getCodConvenio();
      }else if(hint.equals("TPN")){
          valorComparacion = convenioFiltrado(serie.getConvenios(), "T").getCodConvenio();
      }else if(hint.equals("PAIS ORIGEN")){
          valorComparacion = serie.getPaisOrigen().getCodDesc().toLowerCase();
      }else if(hint.equals("ESTADO MERCANCIA")){
          valorComparacion = serie.getCodEstMerc().getCodDesc().toLowerCase();
      }else{//default considera desComer + desFormaPresen + desMateComp + desUsoAplic + desOtrosCarac
          valorComparacion = (serie.getDesComer().concat(" - ").concat(serie.getDesFormaPresen())
                  .concat(" - ").concat(serie.getDesMateComp()).concat(" - ").concat(serie.getDesUsoAplic())
                  .concat(" - ").concat(serie.getDesOtrosCarac()) ).toLowerCase();
      }
      return valorComparacion;
  }

  public Convenio convenioFiltrado(List<Convenio> convenios, String tipoConvenio){
        Convenio result = new Convenio();
        for(Convenio convenio: convenios){
            if(tipoConvenio.equals(convenio.getTipConvenio())){
                result = convenio;
                break;
            }
        }

      return result;
  }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {

        public TextView numSecSerie, partida,descripcion;
        public ImageButton bt_expand;
        public View lyt_expand;
        public View lyt_parent;

        public OriginalViewHolder(View v) {
            super(v);
            numSecSerie = (TextView) v.findViewById(R.id.text_view_num_serie);
            descripcion = (TextView) v.findViewById(R.id.text_view_descripcion);
            partida = v.findViewById(R.id.text_view_partida);
            bt_expand = (ImageButton) v.findViewById(R.id.bt_expand_series);
            lyt_expand = (View) v.findViewById(R.id.lyt_expand_series);
            lyt_parent = (View) v.findViewById(R.id.lyt_parent_series);
        }
    }

    public void sorted(String tipoOrdenamiento) {
        if(tipoOrdenamiento.equals("SERIE")) {
            Collections.sort(this.series.getSeries(), (o1, o2) -> o1.getNumSecSerie().compareTo(o2.getNumSecSerie()));
            this.series.setSeriesFiltradas(this.series.getSeries());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("PARTIDA")) {
            Collections.sort(this.series.getSeries(), (o1, o2) -> o1.getNumPartNandi().compareTo(o2.getNumPartNandi()));
            this.series.setSeriesFiltradas(this.series.getSeries());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("DESCRIPCION")) {
            //Collections.sort(this.series.getSeries(), (o1, o2) -> o1.getDesComer().compareTo(o2.getDesComer()));
            Collections.sort(this.series.getSeries(), (o1, o2) -> o1.getDesComer().concat(" - ").concat(o1.getDesFormaPresen())
                    .concat(" - ").concat(o1.getDesMateComp()).concat(" - ").concat(o1.getDesUsoAplic())
                    .concat(" - ").concat(o1.getDesOtrosCarac()).compareTo(o2.getDesComer().concat(" - ").concat(o2.getDesFormaPresen())
                    .concat(" - ").concat(o2.getDesMateComp()).concat(" - ").concat(o2.getDesUsoAplic())
                    .concat(" - ").concat(o2.getDesOtrosCarac())));
            this.series.setSeriesFiltradas(this.series.getSeries());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("FOB")) {
            Collections.sort(this.series.getSeries(), (o1, o2) -> o2.getMtoFobDol().compareTo(o1.getMtoFobDol()));
            this.series.setSeriesFiltradas(this.series.getSeries());//ordenadas
            notifyDataSetChanged();
        }else{
            Collections.sort(this.series.getSeries(), (o1, o2) -> o1.getNumSecSerie().compareTo(o2.getNumSecSerie()));
            this.series.setSeriesFiltradas(this.series.getSeries());//ordenadas
            notifyDataSetChanged();
        }
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}
