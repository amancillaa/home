package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.ErrorGeneral;

public class DiligenciaResponse extends BaseResponse {

    private Diligencia diligencia;
    private String idDam;

    public DiligenciaResponse(Diligencia diligencia, String idDam) {
        this.diligencia = diligencia;
        this.idDam = idDam;
        this.error = null;
        this.errorGeneral = null;
    }

    public DiligenciaResponse(ErrorGeneral errorGeneral) {
        this.diligencia = null;
        this.error = null;
        this.errorGeneral = errorGeneral;
        this.diligencia = null;
        this.idDam = null;
    }


    public DiligenciaResponse(Throwable error) {
        this.diligencia = null;
        this.error = error;
        this.errorGeneral = null;
        this.diligencia = null;
        this.idDam = null;
    }

    public String getIdDam() {
        return idDam;
    }

    public void setIdDam(String idDam) {
        this.idDam = idDam;
    }

    public Diligencia getDiligencia() {
        return diligencia;
    }

    public void setDiligencia(Diligencia diligencia) {
        this.diligencia = diligencia;
    }
}
