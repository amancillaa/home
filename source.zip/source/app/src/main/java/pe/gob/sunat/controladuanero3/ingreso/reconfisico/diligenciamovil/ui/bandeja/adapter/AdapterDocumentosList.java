package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.ui.bandeja.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.R;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentoAsignado;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.DocumentosAsignados;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ItemAnimation;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.Tools;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.util.ViewAnimation;

public class AdapterDocumentosList extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements Filterable {

    private DocumentosAsignados documentosAsignados;
    private Context ctx;
    private OnItemClickListener mOnItemClickListener;
    private int animation_type = 0;


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();

                String hint = !charString.isEmpty() && charString.contains(":")?
                        charString.substring(0,charString.indexOf(":")):"";

                if(!hint.isEmpty()) {
                    charString = charString.substring(charString.indexOf(":") + 1);
                }

                if (charString.isEmpty() && hint.isEmpty()) {
                    documentosAsignados.setDocumentosFiltrados(documentosAsignados.getDocumentos());
                }else{

                    List<DocumentoAsignado> lstDocsPorQuery = new ArrayList<>();

                    for (DocumentoAsignado doc : documentosAsignados.getDocumentos()) {
                        boolean registrarDam = false;
                        if(!hint.isEmpty()){
                        if(hint.equals("G160") && doc.getTieneGarantia160()){
                            registrarDam = true;
                            }else if(hint.equals("OEA") && doc.getEsOEA()){
                            registrarDam = true;
                            }
                        }else{//hint vacio mandan iddam
                            if (doc.getIdDam().contains(charString.toLowerCase()) ) {
                                registrarDam = true;
                            }
                        }

                        if (registrarDam) {
                            lstDocsPorQuery.add(doc);
                        }
                        }
                    if(hint.isEmpty() && lstDocsPorQuery.size()==0){
                        documentosAsignados.setDocumentosFiltrados(documentosAsignados.getDocumentos());
                    }else {
                        documentosAsignados.setDocumentosFiltrados(lstDocsPorQuery);
                    }
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = documentosAsignados.getDocumentosFiltrados();
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                documentosAsignados.setDocumentosFiltrados((List<DocumentoAsignado>) filterResults.values);
                notifyDataSetChanged();
            }
        };
    }

    public void sorted(String tipoOrdenamiento) {
        if(tipoOrdenamiento.equals("IDDAM")) {
            Collections.sort(this.documentosAsignados.getDocumentos(), (o1, o2) -> o1.getIdDam().compareTo(o2.getIdDam()));
            this.documentosAsignados.setDocumentosFiltrados(this.documentosAsignados.getDocumentos());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("FECHA_ASIG")) {
            Collections.sort(this.documentosAsignados.getDocumentos(), (o1, o2) -> o1.getFecAsignacion().compareTo(o2.getFecAsignacion()));
            this.documentosAsignados.setDocumentosFiltrados(this.documentosAsignados.getDocumentos());//ordenadas
            notifyDataSetChanged();
        }else if(tipoOrdenamiento.equals("CANTSERIES")) {
            Collections.sort(this.documentosAsignados.getDocumentos(), (o1, o2) -> o1.getCantTotSeries().compareTo(o2.getCantTotSeries()));
            this.documentosAsignados.setDocumentosFiltrados(this.documentosAsignados.getDocumentos());//ordenadas
            notifyDataSetChanged();
        }else{
            Collections.sort(this.documentosAsignados.getDocumentos(), (o1, o2) -> o1.getIdDam().compareTo(o2.getIdDam()));
            this.documentosAsignados.setDocumentosFiltrados(this.documentosAsignados.getDocumentos());//ordenadas
            notifyDataSetChanged();
        }
    }

    public interface OnItemClickListener {
        void onItemClick(View view, DocumentoAsignado documento, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public AdapterDocumentosList(Context context, DocumentosAsignados documentosAsignados, int animation_type) {
        this.documentosAsignados = documentosAsignados;
        this.documentosAsignados.setDocumentosFiltrados(documentosAsignados.getDocumentos());
        ctx = context;
        this.animation_type = animation_type;
    }


    public void addItems(DocumentosAsignados documentosAsignados){
        this.documentosAsignados = documentosAsignados;
        this.documentosAsignados.setDocumentosFiltrados(documentosAsignados.getDocumentos());
        notifyDataSetChanged();
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        public ImageView image, indGar160, indOea;
        public TextView idDam, partida, fecNumeracion, fecAsignacion, cantSeries;
        public ImageButton bt_expand;
        public View lyt_expand;
        public View lyt_parent;

        public OriginalViewHolder(View v) {
            super(v);
            image = (ImageView) v.findViewById(R.id.image);
            idDam = (TextView) v.findViewById(R.id.idDam);
            partida = v.findViewById(R.id.text_view_partida);
            fecNumeracion = v.findViewById(R.id.text_view_fecha_numeracion);
            fecAsignacion = v.findViewById(R.id.text_view_fecha_asignacion);
            cantSeries = v.findViewById(R.id.text_view_cant_series);
            indGar160 = (ImageView) v.findViewById(R.id.ind_img_gar160);
            indOea = (ImageView)v.findViewById(R.id.ind_img_oea);
            bt_expand = (ImageButton) v.findViewById(R.id.bt_expand_documentos);
            lyt_expand = (View) v.findViewById(R.id.lyt_expand_documentos);
            lyt_parent = (View) v.findViewById(R.id.lyt_parent_documentos);

        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_documentos_list, parent, false);
        vh = new OriginalViewHolder(v);
        return vh;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof OriginalViewHolder) {
            final OriginalViewHolder view = (OriginalViewHolder) holder;

            final DocumentoAsignado documento = documentosAsignados.getDocumentosFiltrados().get(position);
            view.idDam.setText(documento.getIdDam());
            view.fecNumeracion.setText(documento.getFecNumeracion());
            view.fecAsignacion.setText(documento.getFecAsignacion());
            view.cantSeries.setText(documento.getCantTotSeries().toString());
            if(documento.getTieneGarantia160()){
                view.indGar160.setVisibility(View.VISIBLE);
            }else{
                view.indGar160.setVisibility(View.INVISIBLE);
            }
            if(documento.getEsOEA()){
                view.indOea.setVisibility(View.VISIBLE);
            }else{
                view.indOea.setVisibility(View.INVISIBLE);
            }

            view.lyt_parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onItemClick(view, documento, position);
                    }
                }
            });

            view.bt_expand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean show = toggleLayoutExpand(!documento.isExpanded() , v, view.lyt_expand);
                    documentosAsignados.getDocumentosFiltrados().get(position).setExpanded(show);
                }
            });

            if(documento.isExpanded()){
                view.lyt_expand.setVisibility(View.VISIBLE);
            } else {
                view.lyt_expand.setVisibility(View.GONE);
            }
            Tools.toggleArrow(documento.isExpanded(), view.bt_expand, false);

            setAnimation(holder.itemView, position);
        }
    }

    private boolean toggleLayoutExpand(boolean show, View view, View lyt_expand) {
        Tools.toggleArrow(show, view);
        if (show) {
            ViewAnimation.expand(lyt_expand);
        } else {
            ViewAnimation.collapse(lyt_expand);
        }
        return show;
    }

    @Override
    public int getItemCount() {
        return documentosAsignados.getDocumentos()!=null?
                documentosAsignados.getDocumentosFiltrados().size(): 0;
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                on_attach = false;
                super.onScrollStateChanged(recyclerView, newState);
            }
        });
        super.onAttachedToRecyclerView(recyclerView);
    }

    private int lastPosition = -1;
    private boolean on_attach = true;

    private void setAnimation(View view, int position) {
        if (position > lastPosition) {
            ItemAnimation.animate(view, on_attach ? position : -1, animation_type);
            lastPosition = position;
        }
    }
}