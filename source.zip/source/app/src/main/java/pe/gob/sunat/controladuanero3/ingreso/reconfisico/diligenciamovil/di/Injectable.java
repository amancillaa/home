package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.di;
/**
 * Marca para fragment
 */
public interface Injectable {
}
