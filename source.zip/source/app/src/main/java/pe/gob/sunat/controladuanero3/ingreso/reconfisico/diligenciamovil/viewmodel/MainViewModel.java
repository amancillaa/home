package pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.support.annotation.NonNull;


import javax.inject.Inject;

import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.model.Diligencia;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.AdvertenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.DiligenciaResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.api.response.FotoResponse;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.AsignacionRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DamRepository;
import pe.gob.sunat.controladuanero3.ingreso.reconfisico.diligenciamovil.repository.DiligenciaRepository;
import timber.log.Timber;

public class MainViewModel extends AndroidViewModel {

    public static final String TAG = MainViewModel.class.getSimpleName();

    private LiveData<FotoResponse> fotoResponse;
    private LiveData<DiligenciaResponse> diligenciaResponse;
    private LiveData<AdvertenciaResponse> advertenciaResponse;
    private AsignacionRepository asignacionRepository;
    private DiligenciaRepository diligenciaRepository;
    private DamRepository damRepository;


    @Inject
    public MainViewModel(
            @NonNull Application application,
            @NonNull AsignacionRepository asignacionRepository,
            @NonNull DiligenciaRepository diligenciaRepository,
            @NonNull DamRepository damRepository) {
        super(application);

        this.asignacionRepository = asignacionRepository;
        this.diligenciaRepository = diligenciaRepository;
        this.damRepository = damRepository;
        fotoResponse = new MediatorLiveData<>();
        diligenciaResponse = new MediatorLiveData<>();
        advertenciaResponse = new MediatorLiveData<>();
    }

    public LiveData<FotoResponse> getFoto(String token, String codFuncionario){

        if(fotoResponse.getValue()==null
                || !codFuncionario.equals(fotoResponse.getValue().getCodFuncionario())){
            //fotoResponse.addSource(asignacionRepository.getFoto(token,codFuncionario),imagenResponse -> fotoResponse.setValue(imagenResponse));

            fotoResponse = asignacionRepository.getFoto(token,codFuncionario);
        }

        Timber.d("getFoto(codFuncionario:%s)->response(%s)",codFuncionario,fotoResponse.getValue());
        return fotoResponse;
    }

    public LiveData<DiligenciaResponse> postDiligencia(String token, Diligencia diligencia, String idDam) {

        if(diligenciaResponse.getValue()==null
                || diligenciaResponse.getValue().getDiligencia()==null
                ||!idDam.equals(diligenciaResponse.getValue().getIdDam())
                ||!diligencia.equals(diligenciaResponse.getValue().getDiligencia()) ) {

            diligenciaResponse = diligenciaRepository.registrarDiligencia(token,diligencia,idDam);
        }

        Timber.d("postDiligencia(diligencia:%s,idDam:%s)->response(%s)",diligencia,idDam,diligenciaResponse.getValue());
        return diligenciaResponse;
    }
    public LiveData<AdvertenciaResponse> getListaAdvertencias(String token, String idDam, String tipo){

        String pk = idDam.concat("-").concat(tipo);

        if(advertenciaResponse.getValue()==null
                || !pk.equals(advertenciaResponse.getValue().getPk())) {

            advertenciaResponse = damRepository.getAdvertencias(token,idDam, tipo);
        }

        Timber.d("getListaAdvertencias(idDam:%s,tipo:%s)->response(%s)",idDam,tipo,advertenciaResponse.getValue());
        return advertenciaResponse;
    }
}
